  
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package dnacomputing;

import java.io.*;
import java.util.*;


/**
 *
 * @author godar
 */
// Created by Godar J. Ibrahim, Year 2011
// godar.ibrahim@su.edu.krd
// godar@awrosoft.com

public class DNA
{

    public int crossingNodesNo=1,totalEvolPopulaition=100,evolGenerationStep=0;
    public String lastLeastWeight;
    String problem="SP";
    
    private static Random m_rand = new Random();  // random-number generator
    public ArrayList<String> fileLines= new ArrayList<String>();
    
    ArrayList<String> tempPcrCross=new ArrayList<String>();
    ArrayList<String> tempSccpCross=new ArrayList<String>();
    ArrayList<String> lastGeneration=new ArrayList<String>();
    boolean makeReplaceAddStartEnd=false;
    
    public int wrongRoutes=0,crossOverType=0;
    private String inputFile="shortestPath.txt";
    public long startTime,endTime; // for calculating elapsed time
    public float initializePeriod,randomSolPeriod, pcrPeriod, gelPeriod, sscpPeriod, geneticPeriod,otherPeriod;

    public int solutionGeneretingIterations=0, annealingIterations=0,pcrMutations=0,sscpMutations=0,
            ePCRgenerated=0,eSscpGenerated=0,initilaDropedPCR=0,initialDropedsscp=0;

    FileWriter fstream; // For Mutations
    BufferedWriter out;


    public ArrayList<String> distinctVertices= new ArrayList<String>();
    public Hashtable verticesStrands = new Hashtable();      // vertise name, vertise strand
    public Hashtable verticesVersaStrands = new Hashtable(); // vertise strand, vertise name
    public Hashtable compVerticesStrands = new Hashtable();  // vertise name, vertise comp strand
    public Hashtable revesredCompVerticesStrands = new Hashtable(); // vertise name, vertise reversed comp strand

    public String startNode="", endNode="";             // start & end node names
    public String startNodeStrand="", endNodeStrand="";  // start & end node strands

    public ArrayList<String> edgeStrands= new ArrayList<String>(); // strands of all edges
    public ArrayList<String> nodeStrands= new ArrayList<String>(); // strands of all vertices
    
    int palindromeDNA=10;  // length of the palidrome strand
    
    
    
    public ArrayList<String> edges= new ArrayList<String>(); // all Edges: A-B
    public Hashtable edgeStrandsHash = new Hashtable();     // Edge Strands: A-B, ATGCTGACTG
    public Hashtable edgeWeights = new Hashtable();         // Edge Wrights: A-B, 3
    public Hashtable jobWeights = new Hashtable();  
    public Hashtable jobStrandWeights = new Hashtable();  
    public Hashtable sythWeights = new Hashtable();
    public Hashtable gelWeights = new Hashtable();
    public Hashtable weightedRealSolutions = new Hashtable();

    public List<String> weights = new ArrayList<String>();
    
    public ArrayList<String> testTube= new ArrayList<String>();   // Containing Node & Edge Strands
    public ArrayList<String> randomSolutions= new ArrayList<String>(); // Saving Random Solution Strands
    public ArrayList<String> secondRandomSolutions= new ArrayList<String>(); // in case if we have two PCR steps
    
    public ArrayList<String> pcrSolutions= new ArrayList<String>(); // Saving PCR Solution Strands
    public ArrayList<String> firstPcrSolutions= new ArrayList<String>(); // Saving PCR Solution Strands
    
    public ArrayList<String> tempPcrSolutions= new ArrayList<String>(); // Saving PCR Solution Strands
    public ArrayList<String> tempSscpSolutions= new ArrayList<String>();
    public ArrayList<String> droppedPcrSolutions= new ArrayList<String>(); // Saving PCR Solution Strands
    public ArrayList<String> geneticSolutions= new ArrayList<String>(); // Saving PCR Solution Strands
    public ArrayList<String> pcrRealSolutions= new ArrayList<String>(); // Saving PCR Solution with real names
    public ArrayList<String> gelSolutions= new ArrayList<String>(); // Saving Gel Solution Strands
    public ArrayList<String> sscpSolutions= new ArrayList<String>(); // Saving sscpesized Solution Strands
    public ArrayList<String> firstSscpSolutions= new ArrayList<String>(); // Saving sscpesized Solution Strands
    public ArrayList<String> firstSscpSolutionsForEvolSSCP= new ArrayList<String>(); // Saving sscpesized Solution Strands
    public ArrayList<String> dropedSscpSolutions= new ArrayList<String>(); //
    public ArrayList<String> sscpRealSolutions= new ArrayList<String>(); // Saving sscpesized Solution Strands with real Node Names
    public ArrayList<String> weightedRealSolution= new ArrayList<String>(); // Saving sscpesized Solution Strands with real Node Names

    public ArrayList<String> seperatedNodes= new ArrayList<String>(); // Saving separated Node Strands from Solution Strands
    public ArrayList<String> weightedSeperatedNodes= new ArrayList<String>(); // Saving separated Node Strands from Solution Strands
    public ArrayList<String> mutationSeperatedNodes= new ArrayList<String>();
    public ArrayList<String> semiCrossSeperatedNodes= new ArrayList<String>();
    public ArrayList<String> pcrSeperatedNodes= new ArrayList<String>();
    public ArrayList<String> sccpSeperatedNodes= new ArrayList<String>();
    
    
    public String bestSol="",tempSol="",tempWeight="",leastWeight="10000";
    public String tempWait="",tempTurn="",lastWait="20000",lastTurn="20000";
    public String bestSolution="";
    public ArrayList<String> randomSscpSolutions= new ArrayList<String>(); // 
    public ArrayList<String> evolSolHistoryList= new ArrayList<String>(); // 
    public Hashtable evolSolHistoryTable = new Hashtable();
    public ArrayList<String> nextGeneration= new ArrayList<String>(); // 
    public int evolCrossOvers=0;
    
    
    //==================================================================================
    //      Genetic Algorithm
    //==================================================================================  
    private String mutateBase(String origStrand)
    {
        StringBuffer mutated=new StringBuffer(origStrand);
        Random rndNum = new Random();
        int randN;

        for(int i=0;i<origStrand.length();i++)
        {
           // randN = rndNum.nextInt(origStrand.length());
           // mutated.replace(randN, randN+1, getComplementBase(mutated.substring(randN, randN+1)));
           // mutated.replace(i, i+1, getComplementBase(mutated.substring(i, i+1)));
            mutated.replace(i, i+1, getRandomBase());

        }
        //Utilities.showMessage(origStrand+"\n\n"+mutated.toString(), "");
        return mutated.toString();
        //return generateRandomStrand(origStrand.length());
    }
    //==================================================================================
    private String getRandomBase()
    {
        String charset = "ATGC";

          Random rand = new Random(System.currentTimeMillis());
          StringBuilder sb = new StringBuilder();
          int pos = rand.nextInt(charset.length());
          sb.append(charset.charAt(pos));
          //sleep(1);
          return sb.toString();
    }
    //==================================================================================
    private String reorderStrand(String origStrand)
    {
        StringBuffer mutated=new StringBuffer("");
        Random rndNum = new Random();
        int randN;
        mutationSeperatedNodes=getChunkStrings(origStrand,palindromeDNA);
        for(int i=0;i<mutationSeperatedNodes.size();i++)
        {
            randN= rndNum.nextInt(mutationSeperatedNodes.size());
            mutated.append(mutateBase(mutationSeperatedNodes.get(randN)));
        }
       // Utilities.showMessage(origStrand+"\n\n"+mutated.toString(), "");
        return mutated.toString();
    }
    //==================================================================================
    public void initializae(String inFile)
    //Steps: 1-Watson-Crick Pairing, 2-Polymerase, 3-Ligase, 4-Restriction Enzymes
    {         
        startTime = System.currentTimeMillis();
        inputFile=inFile;
        solutionGeneretingIterations=0;
        annealingIterations=0;
        
        fileLines=getFileContens(); // get the contents of the input file, line by line
        if(inFile.startsWith("Networ")) // Shortest Path
        {
            distinctVertices=getDistinctVerticesEdges(fileLines); // returns distinct Nodes and save Edge & Edge Weights
            verticesStrands=generateRandomStrands(distinctVertices); // returns generated random Strand for Nodes and save them in Test Tube
            edgeStrandsHash=getEdgeStrandsHash(edges, verticesStrands);  // returns strands of edges and save them in Test Tube
        }
        else
        {
            distinctVertices=getDistinctVerticesEdgesSchedule(fileLines); // returns distinct Nodes and save Edge & Edge Weights
            verticesStrands=generateRandomStrandsSchedule(distinctVertices); // returns generated random Strand for Nodes and save them in Test Tube
            edgeStrandsHash=getEdgeStrandsHashSchedule(edges, verticesStrands);  // returns strands of edges and save them in Test Tube            
        }

        endTime = System.currentTimeMillis();
        initializePeriod=(endTime-startTime)/1000F;
    }
     //==================================================================================
    //************************************ Initialize Start *************************************************************
    //==================================================================================
     private ArrayList getFileContens() // getting lines including nodes, routes, weights
    {
        ArrayList<String> list= new ArrayList<String>();

        try{

                FileInputStream fstream = new FileInputStream("D:/Postgraduate Studying/My Thesis/Practical Project/DNAcomputing/src/dnacomputing/"+inputFile);
                DataInputStream in = new DataInputStream(fstream);
                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                String strLine;

                while ((strLine = br.readLine()) != null)
                        list.add(strLine);
                in.close();
             }
            catch (Exception e)
            {
                  Utilities.showMessage("Error: " + e.getMessage(),"");
            }
        return list;
    }
     //==================================================================================
    private ArrayList getDistinctVerticesEdges(ArrayList list)
            // return distinct Nodes and save Edges, Edge Weights
    {
        ArrayList<String> distNodes= new ArrayList<String>();
        String[] temp;
        edges.clear();
        for(int i=0;i<list.size();i++)
        {
            temp = (list.get(i)+"").split(",");
            if(i==0)
            {
                startNode=temp[0];
                endNode=temp[1];
            }
            else
            {
                distNodes.add(temp[0]);
                distNodes.add(temp[1]);

                edges.add(temp[0]+"-"+temp[1]); // save all edges here
                edgeWeights.put(temp[0]+"-"+temp[1],temp[2]);
            }
        }

        HashSet hs = new HashSet();
        hs.addAll(distNodes); //to sort them
        distNodes.clear();
        distNodes.addAll(hs);

        Collections.sort(distNodes); // sorting the vertices
        return distNodes;

    }
    //==================================================================================
    public void calculateJobWaitsTurns()
    {
        Enumeration e = weightedRealSolutions.keys(); // having final job strands
        
        String nextElemenet="";
        while( e. hasMoreElements() )
        {
            nextElemenet=e.nextElement()+""; // the strand of the solution
            seperatedNodes=getChunkStrings(nextElemenet,palindromeDNA);
            
            for(int i=0;i<seperatedNodes.size();i++)
            {


            }
         }
        
    }            
    //==================================================================================
    private ArrayList getDistinctVerticesEdgesSchedule(ArrayList list)
            // return distinct Nodes and save Edges, Edge Weights
    {
        ArrayList<String> distNodes= new ArrayList<String>();
        String[] temp;
        edges.clear();
        for(int i=0;i<list.size();i++)
        {
            temp = (list.get(i)+"").split(",");
            distNodes.add(temp[0]);
            if(i!=0) 
            {
                edges.add(distNodes.get(i-1) +"-"+temp[0]); // save all edges here
               // edges.add(temp[0]+"-"+distNodes.get(i-1)); // save all edges here
            }
            if(i==0)
                startNode=temp[0];
            if(i==list.size()-1)
                endNode=temp[0];
                
           if(i==list.size()-1)
                edges.add( temp[0]+"-"+distNodes.get(0)); // save all edges here
           
           jobWeights.put(temp[0], temp[1]); // save the time of the jobs
        }

        HashSet hs = new HashSet();
        hs.addAll(distNodes); //to sort them
        distNodes.clear();
        distNodes.addAll(hs);

        Collections.sort(distNodes); // sorting the vertices
        return distNodes;
    }
    //=================================================================================
    private Hashtable generateRandomStrands(ArrayList list)
            // returns generated random Strand for Nodes and save them in Test Tube
    {   
        Hashtable strandsDic=new Hashtable();
        compVerticesStrands.clear();
        revesredCompVerticesStrands.clear();
        testTube.clear();
        nodeStrands.clear();

        String tempStrand="";
        for(int i=0;i<list.size();i++)
        {
            tempStrand=generateRandomStrand(palindromeDNA);
            nodeStrands.add(tempStrand);
            strandsDic.put(list.get(i)+"",tempStrand);
            verticesVersaStrands.put(tempStrand, list.get(i)+"");
            compVerticesStrands.put(list.get(i)+"", getComplementStrand(tempStrand));
            revesredCompVerticesStrands.put(list.get(i)+"",getReverseStrand(getComplementStrand(tempStrand)));

            testTube.add(tempStrand); // put node Strand into Test Tube
        }
        startNodeStrand=strandsDic.get(startNode)+"";
        endNodeStrand=strandsDic.get(endNode)+"";

        return strandsDic;
    }
    //=================================================================================
    private Hashtable generateRandomStrandsSchedule(ArrayList list)
            // returns generated random Strand for Nodes and save them in Test Tube
    {   
        Hashtable strandsDic=new Hashtable();
        compVerticesStrands.clear();
        revesredCompVerticesStrands.clear();
        testTube.clear();
        nodeStrands.clear();

        String tempStrand="";
        for(int i=0;i<list.size();i++)
        {
            tempStrand=generateRandomStrand(palindromeDNA);
            nodeStrands.add(tempStrand);
            strandsDic.put(list.get(i)+"",tempStrand);
            verticesVersaStrands.put(tempStrand, list.get(i)+"");
            compVerticesStrands.put(list.get(i)+"", getComplementStrand(tempStrand));
            revesredCompVerticesStrands.put(list.get(i)+"",getReverseStrand(getComplementStrand(tempStrand)));

            testTube.add(tempStrand); // put node Strand into Test Tube
            jobStrandWeights.put(distinctVertices.get(i), tempStrand);
        }
        startNodeStrand=strandsDic.get(startNode)+"";
        endNodeStrand=strandsDic.get(endNode)+"";
        return strandsDic;
    }
     //==================================================================================
    private void duplicateTestTube()
    {
        for(int i=0;i<testTube.size();i++)
            testTube.add(testTube.get(i));
    }
    //==================================================================================
     private String generateRandomStrand(int length)
     {
          String charset = "ATGC";

          Random rand = new Random(System.currentTimeMillis());
          StringBuilder sb = new StringBuilder();
          for (int i = 0; i < length; i++)
          {
                int pos = rand.nextInt(charset.length());
                sb.append(charset.charAt(pos));
          }
          sleep(10);
          return sb.toString();
     }
     //==================================================================================
     public static void sleep(int secs)
     {
          try
          {
                Thread.sleep(secs);
          } catch (InterruptedException e)
          {e.printStackTrace();}
     }
     //==================================================================================
    private Hashtable getEdgeStrandsHash(ArrayList allEdges, Hashtable vericeStrands)
            // returns strands of edges and save them in Test Tube
    {
        Hashtable edgeStrand=new Hashtable();
        String[] temp;
        String ligasedStrand="";

        edgeStrands.clear();
        for(int i=0;i<allEdges.size();i++)
        {
            temp=(allEdges.get(i)+"").split("-");
            ligasedStrand=makeEdge(vericeStrands.get(temp[0])+"",vericeStrands.get(temp[1])+"");
            edgeStrand.put(allEdges.get(i)+"",ligasedStrand);

            edgeStrands.add(ligasedStrand);
            testTube.add(ligasedStrand); // Put Edge Strand in Test Tube
            //testTube.add(ligasedStrand); // Put Edge Strand in Test Tube again; duplication
            //testTube.add(ligasedStrand); // Put Edge Strand in Test Tube again; duplication
        }
       // duplicateTestTube();
        return edgeStrand;
    }
    //==================================================================================
    private Hashtable getEdgeStrandsHashSchedule(ArrayList allEdges, Hashtable vericeStrands)
            // returns strands of edges and save them in Test Tube
    {
        Hashtable edgeStrand=new Hashtable();
        String[] temp;
        String ligasedStrand="";

        edgeStrands.clear();
        for(int i=0;i<allEdges.size();i++)
        {
            temp=(allEdges.get(i)+"").split("-");
            ligasedStrand=makeEdge(vericeStrands.get(temp[0])+"",vericeStrands.get(temp[1])+"");
            edgeStrand.put(allEdges.get(i)+"",ligasedStrand);

            edgeStrands.add(ligasedStrand);
            testTube.add(ligasedStrand); // Put Edge Strand in Test Tube
            //testTube.add(ligasedStrand); // Put Edge Strand in Test Tube again; duplication
            //testTube.add(ligasedStrand); // Put Edge Strand in Test Tube again; duplication
        }
       // duplicateTestTube();
        return edgeStrand;
    }
     //==================================================================================
    private String getReverseStrand(String origStrand)
    {
        String reversed="";

        for (int i=0; i<origStrand.length(); i++)
           reversed = origStrand.substring(i, i+1) + reversed;

           return reversed.toUpperCase();
    }
    //==================================================================================
    private String makeEdge(String firstStrand, String secondStrand)
    {
        String ligised="",second="";
        int halfIndex=firstStrand.length()/2;

        for(int i=0;i<halfIndex;i++)
            ligised+=firstStrand.substring((halfIndex+i),(halfIndex+i)+1);
        ligised=getComplementStrand(ligised);
        for(int j=0;j<halfIndex;j++)
             second+=secondStrand.substring(j,j+1);
        second=getComplementStrand(second);

        return ligised+second;
    }
    //==================================================================================
    private boolean isWrongStrand(String strand)
    {
        String str=strand.toUpperCase();
        for(int i=0;i<str.length();i++)
            if(!str.substring(i, i+1).equals("A") && !str.substring(i, i+1).equals("T")
            && !str.substring(i, i+1).equals("G") && !str.substring(i, i+1).equals("C"))
                return true;

        return false;
    }
    //==================================================================================
    private String getComplementBase(String origBase)
    {
       String comp=origBase;
       if(origBase.equals("A") || origBase.equals("a"))
          comp="T";
        else if(origBase.equals("T") || origBase.equals("t"))
          comp="A";
       else if(origBase.equals("G") || origBase.equals("g"))
          comp="C";
       else if(origBase.equals("C") || origBase.equals("c"))
          comp="G";

       return comp;

    }
    //==================================================================================
    private String getComplementStrand(String origStrand)
    {
        String compStrand="";
        for(int i=0;i<origStrand.length();i++)
            compStrand+=getComplementBase(origStrand.substring(i, i+1));

        return compStrand;
    }
    //==================================================================================
    //************************************ Initialize End *************************************************************
     //==================================================================================
    //************************************ Random Solutions Start *************************************************************
    //==================================================================================
    public void generateRandomSolutiuons(int solutionsNo)
    {
        solutionGeneretingIterations=0;
        annealingIterations=0;
        pcrMutations=0;
        sscpMutations=0;
        ePCRgenerated=0;
        eSscpGenerated=0;
        initilaDropedPCR=0;
        initialDropedsscp=0;
            
        startTime = System.currentTimeMillis();
        randomSolutions.clear();
        
        String node1,node2,edge;
        for(int i=0;i<edgeStrands.size();i++) // initial solutions from nodes,edges
        {
            for(int j=0;j<nodeStrands.size();j++)
            {
                for(int k=0;k<nodeStrands.size();k++)
                {
                    if(j!=k) // preventing checking node by itself
                    {
                        annealingIterations++;
                        node1=nodeStrands.get(j)+"";
                        node2=nodeStrands.get(k)+"";
                        edge=edgeStrands.get(i);

                         if(checkComplemantary(getEnd(node1,palindromeDNA),getStart(edge,palindromeDNA)) &&
                         checkComplemantary(getStart(node2,palindromeDNA),getEnd(edge,palindromeDNA)))
                         {
                              randomSolutions.add(ligase(node1,node2));
                              solutionGeneretingIterations++;
                        }
                    }
                 }
            }            
        }

        copyNodesToRandomSolutions(); // to have them for more ligations

        Random rndmNode1 = new Random();
        Random rndmNode2 = new Random();
        Random rndmEdge = new Random();
        int randN1,randN2,randE;
        
        while(true) // generating random solutions from initial solutions
        {
            randN1 = rndmNode1.nextInt(randomSolutions.size());
            randN2 = rndmNode2.nextInt(randomSolutions.size());
            randE = rndmEdge.nextInt(edgeStrands.size());
            if(randN1!=randN2) // preventing checking node by itself
            {
                 annealingIterations++;
                 if(solutionGeneretingIterations>=solutionsNo)
                        break;

                  node1=randomSolutions.get(randN1)+"";
                  node2=randomSolutions.get(randN2)+"";
                  edge=edgeStrands.get(randE);

                  //palindromeDNA=edge.length()/2;
                  if(checkComplemantary(getEnd(node1,palindromeDNA),getStart(edge,palindromeDNA)) &&
                     checkComplemantary(getStart(node2,palindromeDNA),getEnd(edge,palindromeDNA)))
                  {
                      randomSolutions.add(ligase(node1,node2));
                      solutionGeneretingIterations++;
                  }  
            }
        }
        endTime = System.currentTimeMillis();
        randomSolPeriod=(endTime-startTime)/1000F;
    }
    //==================================================================================
    private void copyNodesToRandomSolutions()
    {
        for(int i=0;i<nodeStrands.size();i++)
            randomSolutions.add(nodeStrands.get(i));
    }
    //==================================================================================
    private Boolean checkComplemantary(String firstStrandCC, String secondStrandDD)
    {
        for(int i=0;i<firstStrandCC.length();i++)
        {
             if(!firstStrandCC.substring(i, i+1).equals(getComplementBase(secondStrandDD.substring(i, i+1))))
                return false;
        }
        return true;
     }
     //==================================================================================
     private String ligase(String strand1, String strand2)
     {
         return strand1+strand2;
     }
     //=================================================================================
    private String getStart(String strand, int strandSize)
            // return the first half of the strand
    {
        String start="";
        for(int i=0;i<strandSize/2;i++)
            start=start+strand.substring(i, i+1);
        return start;
    }
     //=================================================================================
    private String getEnd(String strand,int strandSize)
            // returns the second half of the strand
    {
        String end="";
        for(int i=(strand.length()-(strandSize/2));i<strand.length();i++)
            end=end+strand.substring(i, i+1);
        return end;
    }
    //================================================================================================
    //************************************ Random Solutions End *************************************************************
    //================================================================================================
    //************************************ PCR Start *************************************************************
    //================================================================================================
    public void dnaPCR() // normal DNA PCR Operation
    {
        startTime = System.currentTimeMillis();

        pcrSolutions.clear();
        droppedPcrSolutions.clear();
        
        for(int i=0;i<randomSolutions.size();i++)
            if(isPCR(randomSolutions.get(i)+""))
                if (!getBetweenPrimers(randomSolutions.get(i),startNodeStrand,endNodeStrand).equals(""))
                    pcrSolutions.add(getBetweenPrimers(randomSolutions.get(i),startNodeStrand,endNodeStrand));
                   
        endTime = System.currentTimeMillis();
        pcrPeriod=(endTime-startTime)/1000F;

        pcrRealSolutions=getLastRealNames(pcrSolutions);
    }
    //================================================================================================
    public void dnaPCRSchedule() // normal DNA PCR Operation
    {
        startTime = System.currentTimeMillis();

        pcrSolutions.clear();
        droppedPcrSolutions.clear();
        
        for(int i=0;i<randomSolutions.size();i++)
            if(isPCRschedule(randomSolutions.get(i)+""))
                    pcrSolutions.add(randomSolutions.get(i)+"");
                   
        endTime = System.currentTimeMillis();
        pcrPeriod=(endTime-startTime)/1000F;

        pcrRealSolutions=getLastRealNames(pcrSolutions);
    }
    //================================================================================================
    public boolean isPCRschedule(String strand) // having all the jobs
    {
        for(int i=0;i<nodeStrands.size();i++)
            if(!strand.contains(nodeStrands.get(i)))
                return false;
        return true;
    }
    //================================================================================================
    public void ednaPCR(boolean repAddStEnd,int eDNAtype,String mutationsNo) // evolutionary DNA PCR Operation
    {       
        makeReplaceAddStartEnd=repAddStEnd;
        startTime = System.currentTimeMillis();

        pcrSolutions.clear();
        
        // normal DNA PCR
        getPCRsolutions(randomSolutions,false);
        copyList(pcrSolutions,firstPcrSolutions); // to be used for crossing over
        
        initilaDropedPCR=droppedPcrSolutions.size();
        ePCRgenerated=0;
        pcrMutations=0;
         
        if(makeReplaceAddStartEnd) // first improvement in DNA Algorithm
        {
            correctDropedPCRs(); // replace & add start/end
            ePCRgenerated=ePCRgenerated+tempPcrSolutions.size();
            copyList(tempPcrSolutions,pcrSolutions);
            getPCRsolutions(tempPcrSolutions,true); // adding the corrected droped PCRs to PCR solution
        }
        
        // Evolutionary DNA PCR
        if(eDNAtype==1 || eDNAtype==3) // Second improvement in DNA Algorithm
             makePCRmutations(mutationsNo);

        endTime = System.currentTimeMillis();
        pcrPeriod=(endTime-startTime)/1000F;

        pcrRealSolutions=getLastRealNames(pcrSolutions);
    }
    //==================================================================================
    private void makePCRmutations(String mutationsNo)
    {       
        copyList(droppedPcrSolutions,tempPcrCross); // cross over droped PCRs
        pcrMutations=0;
        
        for(int i=0;i<Integer.parseInt(mutationsNo);i++) // loop for number of mutations
        {        
            tempPcrCross= semiCrossOverPCRs(tempPcrCross); // making cross over and update the list  
            getPCRsolutions(tempPcrCross,true); // adding the crossed over PCRs to PCR list; if they are PCR solutions
        }
    }    
    //==================================================================================
    private void copyList(ArrayList from, ArrayList to)
    {
        to.clear();
        for(int i=0;i<from.size();i++)
            to.add(from.get(i)+"");
    }
    //==================================================================================
    private String makePcrCrossOver(String originStrand,ArrayList<String> getCrossFrom, int loopOut)
    {
        String tempCrossing="";
        ArrayList<String> semiCrossedSeperatedNodes= new ArrayList<String>();
        ArrayList<String> targetSeperatedNodes= new ArrayList<String>();
        try{
            if(originStrand.length()>(palindromeDNA*2)) // in order to crossover middle nodes
            {
                 semiCrossedSeperatedNodes=getChunkStrings(originStrand,palindromeDNA);
                 Random rand = new Random(System.currentTimeMillis());
                 int pcrPos = rand.nextInt(getCrossFrom.size());                 
                 targetSeperatedNodes=getChunkStrings(getCrossFrom.get(pcrPos),palindromeDNA);

                int crossCount=0,count=0;
                while(true)// just crossover two nodes of the working strand
                {
                    rand = new Random(System.currentTimeMillis());
                    int tempPos = rand.nextInt(semiCrossedSeperatedNodes.size());
                    pcrPos = rand.nextInt(targetSeperatedNodes.size()); 
                    crossCount++;
                    pcrMutations++;
                    tempCrossing=originStrand.replace(semiCrossedSeperatedNodes.get(tempPos), targetSeperatedNodes.get(pcrPos));                       
                       
                     if(crossCount==2)
                           break;
                }  
                //Utilities.showMessage(getRealName(originStrand)+"\n"+getRealName(tempCrossing), inputFile);
            }   
             }catch(Exception exp){}
        return tempCrossing;
    }
    //==================================================================================
    private ArrayList<String> semiCrossOverPCRs(ArrayList<String> crossingOver)
    {
        ArrayList<String> temp=new ArrayList<String> ();
        copyList(crossingOver,temp);
        try{
        for(int j=0;j<temp.size();j++)
        {
            String crossedOverStrand=makePcrCrossOver(temp.get(j),firstPcrSolutions,temp.size());
            temp.remove(j);  // remove the pre-crossed over PCR
            temp.add(crossedOverStrand); // add the crossed over PCR               
        }
        }catch(Exception exp){}
        return temp;
    }
    //==================================================================================
    private void correctDropedPCRs() // replace start/end & add start/end
    {
        String tempStrand="";
        try{
        for(int j=0;j<droppedPcrSolutions.size();j++) // refine droped PCRs
        {            
             if(droppedPcrSolutions.get(j).length()>palindromeDNA)
             {
                  tempStrand=replaceStartEnd(droppedPcrSolutions.get(j)); // replace start/end of the strand with original start/end
                  tempPcrSolutions.add(tempStrand);
             }
             tempStrand=addStartEnd(droppedPcrSolutions.get(j)); // add original start/end to the strand 
             tempPcrSolutions.add(tempStrand);
             
         } }catch(Exception exp){}
    }       
    //==================================================================================
    private String addStartEnd(String origStrand)
    {
        return startNodeStrand+origStrand+endNodeStrand;
    }
    //==================================================================================
    private String replaceStartEnd(String origStrand)
    {
        String replacedStrand=origStrand.substring(palindromeDNA,origStrand.length()-palindromeDNA);
        return startNodeStrand+replacedStrand+endNodeStrand;
    }
    //==================================================================================
    private void getPCRsolutions(ArrayList sols,boolean evol)
    {        
        droppedPcrSolutions.clear();
        try{
        for(int i=0;i<sols.size()-1;i++)
        {
            if(isPCR(sols.get(i)+""))
            {
                if (!getBetweenPrimers(sols.get(i)+"",startNodeStrand,endNodeStrand).equals(""))
                    pcrSolutions.add(getBetweenPrimers(sols.get(i)+"",startNodeStrand,endNodeStrand));
                if(evol)
                    ePCRgenerated++;
            }
             else
                droppedPcrSolutions.add(sols.get(i)+"");
        } }catch(Exception exp){}
    }
    //==================================================================================
    private boolean isPCR(String strand)
    {
        if(containPrimers(strand,startNodeStrand,endNodeStrand))
            return true;
        return false;
    }
    //==================================================================================
    private boolean containPrimers(String strand,String primerS, String primerT)
    {
       // Utilities.showMessage(strand+"\n"+primerS+"   ---   "+primerT,(strand.indexOf(primerS)>=0 && strand.indexOf(primerT)>=0)+"");
        if(strand.indexOf(primerS)>=0 && strand.indexOf(primerT)>=0 && strand.indexOf(primerS)<strand.indexOf(primerT))
            return true;
        return false;
    }
    //==================================================================================
    private String getBetweenPrimers(String strand,String primerS, String primerT)
    {
        String pcrStrand="";
        try{
            pcrStrand=strand.substring((strand.indexOf(primerS)),(strand.indexOf(primerT)+palindromeDNA));
        }catch(Exception exp){}
        //Utilities.showMessage(primerS+" - "+primerT+"\n"+strand+"\n"+strand.indexOf(primerS)+" : "+strand.indexOf(primerT)+palindromeDNA+"\n"+pcrStrand, "getBetweenPrimers");
        return pcrStrand;
    }
    //==================================================================================
    //************************************ PCR End *************************************************************
    //==================================================================================
    //************************************ sscp Start *************************************************************
    //==================================================================================
    public void sscp()
    {
        startTime = System.currentTimeMillis();

        sscpSolutions.clear();
        getSSCP(pcrSolutions,false);
        firstSscpSolutionsForEvolSSCP.clear();
        copyList(sscpSolutions,firstSscpSolutionsForEvolSSCP);
        endTime = System.currentTimeMillis();
        sscpPeriod=(endTime-startTime)/1000F;

        sscpRealSolutions=getLastRealNames(sscpSolutions);
    }
    //==================================================================================
    private void getSSCP(ArrayList lis,boolean evol)
    {
        dropedSscpSolutions.clear();
        
        for(int i=0;i<lis.size();i++)
            if(!hasRedundancy(lis.get(i)+""))
            {
              sscpSolutions.add(lis.get(i)+"");
              if(evol)
                  eSscpGenerated++;
            }
            else
                dropedSscpSolutions.add(lis.get(i)+"");
    }
     //==================================================================================
    private void makeSSCPmutations(String mutationsNo)
    {       
        copyList(dropedSscpSolutions,tempSccpCross); 
        try{
        for(int i=0;i<Integer.parseInt(mutationsNo);i++) // loop for number of mutations
        {        
            tempSccpCross= semiCrossOverSSCPs(tempSccpCross); // making cross over and update the list  
            getSSCP(tempSccpCross,true); // adding the crossed over SSCPs to SSCP list; if they are SSCP solutions
        } }catch(Exception exp){}
    }  
    //==================================================================================
    private String makeSsscpCrossOver(String originStrand,ArrayList<String> getCrossFrom, int loopOut)
    {
        String tempCrossing="";
        ArrayList<String> semiCrossedSeperatedNodes= new ArrayList<String>();
        ArrayList<String> targetSeperatedNodes= new ArrayList<String>();
        
        try{
            if(originStrand.length()>(palindromeDNA*2)) // in order to crossover middle nodes
            {
                 semiCrossedSeperatedNodes=getChunkStrings(originStrand,palindromeDNA);
                 Random rand = new Random();
                 int sscpPos = rand.nextInt(getCrossFrom.size()-2)+2;   
                           
                // targetSeperatedNodes=getChunkStrings(getCrossFrom.get(sscpPos),palindromeDNA); // to get from correct SSCP solutions
                 
                int crossCount=0,count=0;
                while(true)// just crossover two nodes of the working strand
                {                    
                    rand = new Random(System.currentTimeMillis());
                    int tempPos = rand.nextInt(semiCrossedSeperatedNodes.size());
                    try{
                    //sscpPos = rand.nextInt(targetSeperatedNodes.size());}catch(Exception exp){ }
                     sscpPos = rand.nextInt(getCrossFrom.size());}catch(Exception exp){ }
                    // to avoid cross overing start/end
                    //if(tempPos!=0 && sscpPos!=0 && tempPos!=semiCrossedSeperatedNodes.size()-1 && sscpPos!=targetSeperatedNodes.size()-1)                    
                    if(tempPos!=0 && sscpPos!=0 && tempPos!=semiCrossedSeperatedNodes.size()-1 && sscpPos!=getCrossFrom.size()-1)                    
                    {
                       crossCount++;
                       sscpMutations++;
                       //tempCrossing=originStrand.replace(semiCrossedSeperatedNodes.get(tempPos), targetSeperatedNodes.get(sscpPos));                       
                       tempCrossing=originStrand.replace(semiCrossedSeperatedNodes.get(tempPos), getCrossFrom.get(sscpPos));                       
                       
                       if(crossCount==2) // crossing over two nodes
                           break;
                    }
                     if((++count)>loopOut)
                         break;
                }  
                //Utilities.showMessage(getRealName(originStrand)+"\n"+getRealName(tempCrossing), inputFile);
            }     }catch(Exception exp){}
        return tempCrossing;
    }
    //==================================================================================
    public void esscp(boolean jssp,boolean evolSSCP,int eDNAtype,String mutationsNo)
    {
        problem="sp";
        if(jssp)
            problem="js";
        startTime = System.currentTimeMillis();
        sscpMutations=0;
        eSscpGenerated=0;
        dropedSscpSolutions.clear();
        sscpSolutions.clear();
         crossOverType=eDNAtype;
        
        // normal DNA SSCP
        getSSCP(pcrSolutions,false); // to get correct SSCPs from PCRs
        //Utilities.showMessage("SSCP Before Evol: "+sscpSolutions.size(),"");
        initialDropedsscp=dropedSscpSolutions.size();
        
        firstSscpSolutionsForEvolSSCP.clear();
        firstSscpSolutions.clear();
        
        copyList(sscpSolutions,firstSscpSolutions); // to be used for crossing over
        copyList(sscpSolutions,firstSscpSolutionsForEvolSSCP);
        
        // Evolutionary DNA SSCP
        if(eDNAtype==2 || eDNAtype==3)
            makeSSCPmutations(mutationsNo);   
        
        if(evolSSCP && jssp)
            evolutionarySSCPSchedule();
        else if(evolSSCP)            
            evolutionarySSCP();
        
        endTime = System.currentTimeMillis();
        sscpPeriod=(endTime-startTime)/1000F;

        sscpRealSolutions=getLastRealNames(sscpSolutions);
    }
    //==================================================================================//==================================================================================
    //==================================================================================//==================================================================================
    //==================================================================================//==================================================================================
    //==================================================================================//==================================================================================
    private void evolutionarySSCP()
    {
            evolSolHistoryList.clear();
            evolSolHistoryTable.clear();            
            nextGeneration.clear();
            randomSscpSolutions.clear();
            bestSolution="";
            
        try
        {
            fstream= new FileWriter("sp-evolutionarySSCP.txt",true);
            out= new BufferedWriter(fstream);
        }catch(Exception e){Utilities.showMessage(e.getMessage(), "Open File Exception");}
        
        try
        {
            randomSscpSolutions=getRandomSolutions(firstSscpSolutionsForEvolSSCP); // ex. 100 out of 450 problem="js";
            bestSolution=getBestSolution(firstSscpSolutionsForEvolSSCP); 
            //Utilities.showMessage("Best sol:"+bestSolution,lastWait+" - "+ lastTurn); 
            randomSscpSolutions.add(bestSolution);  // also add the best one
            
           // Utilities.showMessage("No: "+firstSscpSolutionsForEvolSSCP.size(),"");
            evolSolHistoryList.add(bestSolution);
            evolSolHistoryTable.put(bestSolution, leastWeight);
            copyList(randomSscpSolutions,lastGeneration);

            out.write("Evolutionary SSCP Started:\n");
            
            for(int i=0;i<edges.size()+10;i++)// number of new generations
            {
                evolCrossOvers=0;
                crossingNodesNo=1;
                nextGeneration=generateNextGeneration(randomSscpSolutions);  // generate population from several solutions
                bestSolution=getBestSolution(nextGeneration); 
                
               // Utilities.showMessage("Best: "+bestSolution+"\n W: "+leastWeight+"\n Gen:"+nextGeneration.size(),"");
                sscpSolutions.add(bestSolution); // not needed, just for 
                evolSolHistoryList.add(bestSolution);
                evolSolHistoryTable.put(bestSolution, leastWeight);
                lastLeastWeight=leastWeight;
                // get random + best solutions for next generation
                randomSscpSolutions=getRandomSolutions(nextGeneration);
                randomSscpSolutions.add(bestSolution); // to add the best solution to randomSscpSolutions
                
                try{
                out.write(verticesStrands.size()+"-"+edges.size()+"-CrossOver"+crossOverType+"--"+crossingNodesNo+"--Best Solution: "+bestSolution+"\tWeight: "+leastWeight+"\tCrossOvers: "+evolCrossOvers+"\tGenerated: "+nextGeneration.size()+"\n");
                }catch(Exception exp){}

                //Utilities.showMessage((i+1)+"- Generated: "+nextGeneration.size()+"\t History: "+evolSolHistoryList.size()+
                  //     "\nBest Sol: "+bestSolution+"\t-->: "+leastWeight+"\nCrossOvers: "+evolCrossOvers, inputFile);
            }
             try{out.close(); }catch(Exception exp){}
             
             //Utilities.showMessage("SSCP After Evol: "+sscpSolutions.size(),"");
            //Utilities.showMessage("Final Best: "+getBestSolution(evolSolHistoryList)+": "+leastWeight, inputFile);
            sscpSolutions.add(getBestSolution(evolSolHistoryList)); // to add the final best solution to SSCP Solutions
        }catch(Exception exp){Utilities.showMessage(exp.getMessage(), "Evol SSCP");}
    }
    //==================================================================================//==================================================================================
    private void evolutionarySSCPSchedule()
    {
            evolSolHistoryList.clear();
            evolSolHistoryTable.clear();            
            nextGeneration.clear();
            randomSscpSolutions.clear();
            bestSolution="";
            
        try
        {
            fstream= new FileWriter("js-evolutionarySSCP.txt",true);
            out= new BufferedWriter(fstream);
        }catch(Exception e){Utilities.showMessage(e.getMessage(), "Open File Exception");}
        
        try
        {
            randomSscpSolutions=getRandomSolutions(firstSscpSolutionsForEvolSSCP); // ex. 100 out of 450 problem="js";            
            bestSolution=getBestSolutionSchedule(firstSscpSolutionsForEvolSSCP); 
            //Utilities.showMessage("Best sol:"+bestSolution,lastWait+" - "+ lastTurn); 
            randomSscpSolutions.add(bestSolution);  // also add the best one
            evolSolHistoryList.add(bestSolution);
            evolSolHistoryTable.put(bestSolution, leastWeight);
            copyList(randomSscpSolutions,lastGeneration);

            out.write("Evolutionary SSCP Started:\n");
            
            for(int i=0;i<edges.size()+50;i++)// number of new generations
            {
                evolCrossOvers=0;
                crossingNodesNo=1;
                nextGeneration=generateNextGenerationSchedule(randomSscpSolutions);  // generate population from several solutions
                bestSolution=getBestSolutionSchedule(nextGeneration); 
                
                //Utilities.showMessage("Best: "+bestSolution+"\n W: "+lastWait+"\n T: "+lastTurn+"\n Gen:"+nextGeneration.size(),"");
                sscpSolutions.add(bestSolution); // not needed, just for 
                evolSolHistoryList.add(bestSolution);
                evolSolHistoryTable.put(bestSolution, lastWait);
                randomSscpSolutions=getRandomSolutions(nextGeneration);
                randomSscpSolutions.add(bestSolution); // to add the best solution to randomSscpSolutions
                
                try{
                out.write(verticesStrands.size()+"-"+edges.size()+"-CrossOver"+crossOverType+"--"+crossingNodesNo+"--Best Solution: "+getJobName(bestSolution)+
                        "\tWait: "+lastWait+"\tTurn: "+lastTurn+"\tCrossOvers: "+evolCrossOvers+"\tGenerated: "+nextGeneration.size()+"\n");
                }catch(Exception exp){}

            }
             try{out.close(); }catch(Exception exp){}
             
            sscpSolutions.add(getBestSolutionSchedule(evolSolHistoryList)); // to add the final best solution to SSCP Solutions
        }catch(Exception exp){Utilities.showMessage(exp.getMessage(), "Evol SSCP");}
    }
    //==================================================================================
    private String makeEvolCrossOver(String originStrand,ArrayList<String> getCrossFrom)
    {
        String tempCrossing="";
        ArrayList<String> semiCrossedSeperatedNodes= new ArrayList<String>();
        ArrayList<String> targetSeperatedNodes= new ArrayList<String>();
        int sscpPos=0,count=0,tempPos=0,crossed=0;
        Random rand = new Random();
                
        try
        {
            if(originStrand.length()>(palindromeDNA*2)) // in order to crossover middle nodes
            {
                 semiCrossedSeperatedNodes=getChunkStrings(originStrand,palindromeDNA); // chunking origin strand
                 //sscpPos = rand.nextInt(getCrossFrom.size()-2)+2; // to get node from                
                 //targetSeperatedNodes=getChunkStrings(getCrossFrom.get(sscpPos),palindromeDNA);  // for SSCP Solutions 
                
                                 
                while(true)
                {
                     count++;
                     rand = new Random();
                     try{
                         tempPos = rand.nextInt(semiCrossedSeperatedNodes.size()-2)+1; // get one node from the origin strand
                        //sscpPos = rand.nextInt(targetSeperatedNodes.size()-2)+1; // for SSCP Solutions 
                         sscpPos = rand.nextInt(getCrossFrom.size());   // get one node from the nodes
                     }catch(Exception exp){ /*Utilities.showMessage(exp.getMessage(),"Random");*/}
                     //Utilities.showMessage("Origin Index: "+ tempPos+"\t Other Index: "+sscpPos+"\n Origin: "+originStrand.length()+"\n Other: "+getCrossFrom.size(),"");
                     // to avoid cross overing start/end
                     //if(tempPos!=0 && sscpPos!=0 && tempPos<semiCrossedSeperatedNodes.size()-2 && sscpPos<targetSeperatedNodes.size()-2)   
                     if(tempPos>0 && tempPos<getCrossFrom.size()-1)   // to cross over the nodes between start/end 
                     {
                        // if(!originStrand.contains(targetSeperatedNodes.get(sscpPos))) // to prevent duplicated node in te strand
                          if(!originStrand.contains(getCrossFrom.get(sscpPos))) // to prevent duplicated node in te strand
                         {
                             //tempCrossing=originStrand.replace(semiCrossedSeperatedNodes.get(tempPos), targetSeperatedNodes.get(sscpPos)); 
                              tempCrossing=originStrand.replace(semiCrossedSeperatedNodes.get(tempPos), getCrossFrom.get(sscpPos)); 
                              originStrand=tempCrossing;
                             crossed++;
                             evolCrossOvers++;                             //if((crossed)>((originStrand.length()/palindromeDNA)/4)) // to crossover nodes/4; 7/4=1 nodes
                             
                             
                             if((crossed)==crossingNodesNo) // number of ndoes to be crossed over
                                break;
                         }  
                     }
                     if(count>2000) // prevent infinite loop
                         break;
                }
            }  
            }catch(Exception exp){Utilities.showMessage(exp.getMessage(), "Cross");}
        
            //Utilities.showMessage("Origin: "+originStrand+"\nGetFrom: "+getCrossFrom.get(sscpPos)+"\nTrying: "+count+"  Crossed: "+crossed+"\n O: "+originStrand+"\n O: "+tempCrossing, inputFile);
            //Utilities.showMessage(count+"\n"+getRealName(originStrand)+"\n"+getRealName(tempCrossing), "CrossOver");
        return tempCrossing;
    }
    //==================================================================================
    private String reorderJobs(String origStrand)
    {
        StringBuffer mutated=new StringBuffer("");
        Random rndNum = new Random();
        mutationSeperatedNodes=getChunkStrings(origStrand,palindromeDNA);
        Collections.shuffle(mutationSeperatedNodes, rndNum);
        for(int i=0;i<mutationSeperatedNodes.size();i++)        
            mutated.append(mutationSeperatedNodes.get(i));
        return mutated.toString();
    }
    //==================================================================================
    private String makeEvolCrossOverSchedule(String originStrand,ArrayList<String> getCrossFrom)
    {
        String tempCrossing="";
        int count=0, crossed=0;
        try
        {
            if(originStrand.length()>(palindromeDNA*2)) // in order to crossover middle nodes
            {
                                 
                while(true)
                {
                     count++;
                     tempCrossing=reorderJobs(originStrand);;
                     //if(!hasRedundancy(tempCrossing)) // correct solution
                     {
                         originStrand=tempCrossing;
                         crossed++;
                     }
                     evolCrossOvers++;     
                     if((crossed)==crossingNodesNo) // number of ndoes to be crossed over
                         break;                     
                     else if(count>1000) // prevent infinite loop
                         break;
                }
            }  
            }catch(Exception exp){Utilities.showMessage(exp.getMessage(), "Cross");}
        
           //Utilities.showMessage("Repalce: "+semiCrossedSeperatedNodes.get(tempPos)+"\nWith: "+getCrossFrom.get(sscpPos)+
             //       "\n O: "+originStrand+"\n O: "+tempCrossing, inputFile);            
        return tempCrossing;
    }
    //==================================================================================
    private ArrayList<String> generateNextGeneration(String bestSolu) // generate population/next generation from best solution
    {
        //Utilities.showMessage("NGN Single", "");
        ArrayList<String> tempSols=new ArrayList<String>();
        tempSols.clear();
        String crossedStrand="";
        
        try{
        for(int i=0;i<firstSscpSolutionsForEvolSSCP.size()*10000;i++)
        {
            crossingNodesNo=1;
            crossedStrand=makeEvolCrossOver(bestSolu,firstSscpSolutionsForEvolSSCP);
            //Utilities.showMessage(bestSolu+"\n"+crossedStrand, "");
            if(!crossedStrand.equals(""))
                tempSols.add(crossedStrand);
        }
        }catch(Exception exp){Utilities.showMessage(exp.getMessage(), "Generate NextGen-Single");}
        
        return tempSols;
    }
    //==================================================================================
    private ArrayList<String> generateNextGeneration(ArrayList<String> bestsols) // generate population/next generation from best solutions*****
    {        
        ArrayList<String> tempSols=new ArrayList<String>();
        tempSols.clear();
        String crossedStrand="";
        int  pos=0;
        totalEvolPopulaition=bestsols.size()*20;
        tempSols.add(bestSolution); // to always have the best solution in next generation for manipulation
        try
        {
        //for(int i=0;i<firstSscpSolutionsForEvolSSCP.size()*20;i++)
        for(int i=0;i<totalEvolPopulaition;i++) // for getting randomly
        //for(int i=0;i<bestsols.size();i++) // for getting sequencially
        {
            crossingNodesNo=1;
            evolGenerationStep=i+1;
            
            if(evolGenerationStep==(totalEvolPopulaition/2))
                tempSols.add(bestSolution); // to have the last best solution in the middle
            
            try{if(Integer.parseInt(lastLeastWeight)>=Integer.parseInt(leastWeight) && evolGenerationStep>(totalEvolPopulaition/2)) // strategy parameter!!!
                                 crossingNodesNo=2; else crossingNodesNo=1;}catch(Exception exp){}
            
             Random rand = new Random(System.currentTimeMillis());
             pos =rand.nextInt(bestsols.size()); // get solutions randomly
             //pos=i;
            //crossedStrand=makeEvolCrossOver(bestsols.get(pos),firstSscpSolutionsForEvolSSCP);
            // for(int k=0;k<bestsols.size();k++) // to make more crossovers
             {
                crossedStrand=makeEvolCrossOver(bestsols.get(pos),nodeStrands);
                 //Utilities.showMessage(bestSolu.size()+"",pos+"");
                if(!crossedStrand.equals(""))
                    tempSols.add(crossedStrand);
             }
            
            try{
                   // out.write(bestsols.size()+"("+pos+")- Generated from "+getRealName(bestsols.get(pos))+
                     //      "("+getWeight(bestsols.get(pos))+") --> "+getRealName(crossedStrand)+"("+getWeight(crossedStrand)+")\n");
                }catch(Exception exp){}
        }
        }catch(Exception exp){Utilities.showMessage(exp.getMessage(), "Generate NextGen-Multi "+ bestsols.size());}
        
         tempSols.add(bestSolution); // to always have the best solution in next generation for retrieveing
         if(tempSols.size()>0)
         {
             lastGeneration.clear();
             copyList(tempSols,lastGeneration);
         }
         else // in case if next generation is empty
             copyList(lastGeneration,tempSols);
         
       //Utilities.showMessage("Generated: "+tempSols.size()+" from "+bestSolu.size()+" random solutions","");
        return tempSols;
    }
    //==================================================================================
    private ArrayList<String> generateNextGenerationSchedule(ArrayList<String> bestsols) // generate population/next generation from best solutions*****
    {        
        ArrayList<String> tempSols=new ArrayList<String>();
        tempSols.clear();
        String crossedStrand="";
        int  pos=0;
        totalEvolPopulaition=bestsols.size()*20;
        tempSols.add(bestSolution); // to always have the best solution in next generation for manipulation
        try
        {
        for(int i=0;i<totalEvolPopulaition;i++) // for getting randomly
        {
            crossingNodesNo=1;
            evolGenerationStep=i+1;
            
            if(evolGenerationStep==(totalEvolPopulaition/2))
                tempSols.add(bestSolution); // to have the last best solution in the middle            
            
             Random rand = new Random(System.currentTimeMillis());
             pos =rand.nextInt(bestsols.size()); // get solutions randomly
             
             {
                crossedStrand=makeEvolCrossOverSchedule(bestsols.get(pos),nodeStrands);// cross over for scheduling will not work; duplicating
                if(!crossedStrand.equals(""))
                    tempSols.add(crossedStrand);
             }
            
            try{
                    //out.write(bestsols.size()+"("+pos+")- Generated from "+getJobName(bestsols.get(pos))+
                      //     "("+getTotalWait(getJobName(bestsols.get(pos)))+" : "+getTotalTurn(getJobName(bestsols.get(pos)))+
                        //    ") --> "+getJobName(crossedStrand)+"("+getTotalWait(getJobName(crossedStrand))+" : "+getTotalTurn(getJobName(crossedStrand))+")\n");
                }catch(Exception exp){}
        }
        }catch(Exception exp){Utilities.showMessage(exp.getMessage(), "Generate NextGen-Multi "+ bestsols.size());}
        
         tempSols.add(bestSolution); // to always have the best solution in next generation for retrieveing
         if(tempSols.size()>0)
         {
             lastGeneration.clear();
             copyList(tempSols,lastGeneration);
         }
         else // in case if next generation is empty
             copyList(lastGeneration,tempSols);
         
       //Utilities.showMessage("Generated: "+tempSols.size()+" from "+bestSolu.size()+" random solutions","");
        return tempSols;
    }
    //==================================================================================
    private void addBestSolutions() // to get the 10% of the best solutions and add to randomSolutions
    {
        
        
    }
    //==========================================================================================
    private String getTotalWait(String jobList)
    {
        int totalWait=0,i=0;  
        String[] jobNames=jobList.split("-");
        for(i=1;i<jobNames.length-1;i++) // first and last job wait not calculated
          totalWait+=(Integer.parseInt(jobWeights.get(jobNames[i])+""));
        
        //return (totalWait/(i))+"";
        return totalWait+"";
    }
    //==========================================================================================
    private String getTotalTurn(String jobList)
    {
        int totalTurn=0,i=0;  
        String[] jobNames=jobList.split("-");
        for(i=1;i<jobNames.length;i++) // first and last job wait not calculated
          totalTurn+=(Integer.parseInt(jobWeights.get(jobNames[i])+""));
        
        //return (totalTurn/(i))+"";
        return totalTurn+"";
    }
    //==================================================================================
    private String getBestSolutionSchedule(ArrayList<String> sols) // fitness function for evolutionary algorithm
    {    
        bestSol=sols.get(0);
        lastWait=getTotalWait(getJobName(sols.get(0)));
        lastTurn=getTotalTurn(getJobName(sols.get(0)));
        
                   
            for(int i=1;i<sols.size();i++)
            {               
                //if((Integer.parseInt(getTotalWait(getJobName(sols.get(i)))))<Integer.parseInt(lastWait) &&
                  //      (Integer.parseInt(getTotalTurn(getJobName(sols.get(i)))))<Integer.parseInt(lastTurn))
                try
                 { 
                    //if((Integer.parseInt(getTotalWait(getJobName(sols.get(i))))+Integer.parseInt(getTotalTurn(getJobName(sols.get(i)))))
                      //      <(Integer.parseInt(lastWait)+Integer.parseInt(lastTurn )))
                    // Utilities.showMessage(lastWait+" <> "+getTotalWait(getJobName(sols.get(i))),"");
                     if(Integer.parseInt(getTotalWait(getJobName(sols.get(i))))<(Integer.parseInt(lastWait)))
                    {
                        //Utilities.showMessage("Before\n"+lastWait+" > "+getTotalWait(getJobName(sols.get(i)))+"\n"+getJobName(bestSol),"");
                        lastWait=getTotalWait(getJobName(sols.get(i)));
                        lastTurn=getTotalTurn(getJobName(sols.get(i)));
                        bestSol=sols.get(i);
                        //Utilities.showMessage("After\n"+lastWait+" > "+getTotalWait(getJobName(sols.get(i)))+"\n"+getJobName(bestSol),"");
                    }
                 }catch(Exception exp){Utilities.showMessage(exp.getMessage(), "Get Best Solution");}
            }        
         //Utilities.showMessage("Send\n"+lastWait+" > "+getTotalWait(getJobName(bestSol))+"\n"+getJobName(bestSol),"");
        return bestSol;
    }
    //==================================================================================
    private String getBestSolution(ArrayList<String> sols) // fitness function for evolutionary algorithm
    {     
        bestSol=""; tempWeight=""; tempSol=""; leastWeight="";
        
        try
        {
            for(int j=0;j<sols.size();j++)
            {
                 leastWeight=getWeight(sols.get(j));
                 bestSol=sols.get(j);
                 
                if(!leastWeight.trim().startsWith("No") && !leastWeight.trim().equals(""))
                    break;
            }
            //Utilities.showMessage(leastWeight, inputFile);
            for(int i=0;i<sols.size();i++)
            {
                tempWeight=getWeight(sols.get(i));
                tempSol=sols.get(i);
                
                if(!tempWeight.trim().startsWith("No") && !tempWeight.trim().equals(""))
                    if((Integer.parseInt(tempWeight))<Integer.parseInt(leastWeight))
                    {
                        leastWeight=tempWeight;
                        bestSol=tempSol;          
                    }
            }
        }catch(Exception exp){Utilities.showMessage(exp.getMessage(), "Get Best Solution");}
                
        return bestSol;
    }
    //==================================================================================
    private ArrayList<String> getRandomSolutions(ArrayList<String> tempList) // fitness function for evolutionary algorithm
    {     
        ArrayList<String> sols=new ArrayList<String>();
        
        try
        {
            Random rand = new Random(System.currentTimeMillis());
             int pos =0; 
             int bestSolsNo=tempList.size()/100; // number of best solutions to be taken
             if(bestSolsNo<100)
                 bestSolsNo=tempList.size()/5;
             if(bestSolsNo<10)
                 bestSolsNo=tempList.size();
            // Utilities.showMessage(bestSolsNo+"", tempList.size()+"");
            for(int i=0;i<bestSolsNo;i++)
            {
                pos =rand.nextInt(tempList.size());
                sols.add(tempList.get(pos));
            }
        }catch(Exception exp){Utilities.showMessage(exp.getMessage(), "Get Random Solutions");}
               
        return sols;
    }
    //==================================================================================//==================================================================================
    //==================================================================================//==================================================================================
    //==================================================================================//==================================================================================
    //==================================================================================//==================================================================================
    private ArrayList<String> semiCrossOverSSCPs(ArrayList<String> crossingOver)
    {
        ArrayList<String> temp=new ArrayList<String> ();
        copyList(crossingOver,temp);
        
        try{
        for(int j=0;j<temp.size();j++)
        {
            //String crossedOverStrand=makeSsscpCrossOver(temp.get(j),firstSscpSolutions,temp.size());
            String crossedOverStrand=makeSsscpCrossOver(temp.get(j),nodeStrands,temp.size());
            temp.remove(j);  // remove the pre-crossed over PCR
            temp.add(crossedOverStrand); // add the crossed over PCR               
        }
       }catch(Exception exp){Utilities.showMessage(exp.getMessage(), "Semi CrossOversSSCP");}
        
        return temp;
    }    
    //==================================================================================
    private boolean hasRedundancy(String strand)
    {
        seperatedNodes=getChunkStrings(strand,palindromeDNA);
        HashSet hs = new HashSet();
        hs.addAll(seperatedNodes);
        if(hs.size()<seperatedNodes.size())
            return true;
        return false;
    }
    //==================================================================================
    public String getRealName(String strandString)
    {
        String realNameString="";
        ArrayList<String> sepNodes= new ArrayList<String>();
        sepNodes=getChunkStrings(strandString+"",palindromeDNA);
        for(int j=0;j<sepNodes.size();j++)
           realNameString+=verticesVersaStrands.get(sepNodes.get(j))+"->";

        return realNameString;
    }
    //==================================================================================
    public String getJobName(String strandString)
    {
        String realNameString="";
        ArrayList<String> sepNodes= new ArrayList<String>();
        sepNodes=getChunkStrings(strandString+"",palindromeDNA);
        for(int j=0;j<sepNodes.size();j++)
           realNameString+=verticesVersaStrands.get(sepNodes.get(j))+"-";

        return realNameString;
    }
    //==================================================================================
    public ArrayList getLastRealNames(ArrayList list)
    {
         ArrayList<String> tempList= new ArrayList<String>();
         try{
         for(int i=0;i<list.size();i++)
         {
             seperatedNodes=getChunkStrings(list.get(i)+"",palindromeDNA);
             StringBuffer temp=new StringBuffer("");
             for(int j=0;j<seperatedNodes.size();j++)
                 temp.append(verticesVersaStrands.get(seperatedNodes.get(j))+",");
             tempList.add(temp+"");
        } }catch(Exception exp){}

         return tempList;
    }
     //==================================================================================
    private ArrayList getChunkStrings(String strand, int nchars)
    {
        ArrayList<String> temp= new ArrayList<String>();
        int len = strand.length();

        for (int i=0; i<len; i+=nchars)
        {
            temp.add(strand.substring(i, Math.min(len, i + nchars)));
        }

        return temp;
    }
    //==================================================================================
    //************************************ sscp End *************************************************************
    //==================================================================================
    //************************************ Gel ElectroPhoresis Start *************************************************************
    //==================================================================================
    public void gelElectroPhoresis()
    {
        startTime = System.currentTimeMillis();
        
        getWeigths(sscpSolutions);
        sortSolutions(sythWeights);

        endTime = System.currentTimeMillis();
        gelPeriod=(endTime-startTime)/1000F; //
    }
    //==================================================================================
    private void sortSolutions(Hashtable sourceTable)
    {
        Hashtable tempTable=new Hashtable();
        Iterator it;
        gelWeights.clear();
        Vector v = new Vector(sourceTable.keySet());
        v=sortByLenght(v);
        it = v.iterator();
        while (it.hasNext())
        {
           String element =  (String)it.next();           
           gelWeights.put( element,(String)sourceTable.get(element));
        }

    }
    //==================================================================================
    private Vector sortByLenght(Vector list)
    {
        Vector v = new Vector();
        v=list;

        for(int i=0;i<v.size();i++)
            for(int j=i+1;j<v.size();j++)
            {               
                if((v.get(i)+"").length()>(v.get(j)+"").length())
                {
                    String temp=v.get(i)+"";
                    v.set(i, v.get(j)+"");
                    v.set(j, temp);
                }
            }
        return v;
    }
    //==================================================================================
    public void getWeigths(ArrayList strands)
    {  
        sythWeights.clear();
        weightedRealSolutions.clear();
        weights.clear();
        
        for(int j=0;j<strands.size();j++)
        {
            sythWeights.put(strands.get(j), getWeight(strands.get(j)+""));
            if(!(getWeight(strands.get(j)+"")).trim().startsWith("No") && !(getWeight(strands.get(j)+"")).equals("0"))
                weights.add(getWeight(strands.get(j)+""));
        }
        Collections.sort(weights);
    }
    //==================================================================================
    private String getWeight(String strand)
    {
        String edge="";       
        int weight=0,temp=0;
        weightedSeperatedNodes=getChunkStrings(strand,palindromeDNA);
        weightedRealSolution=getLastRealNames(weightedSeperatedNodes);
        weightedRealSolutions.put(strand, weightedRealSolution);
        try{
        for(int i=0;i<weightedRealSolution.size()-1;i++)
        {
            edge=weightedRealSolution.get(i).replace(',', ' ').trim()+"-"+weightedRealSolution.get(i+1).replace(',', ' ').trim();
            if(edges.contains(edge))
            {
                try
                {
                     temp=Integer.parseInt(edgeWeights.get(edge.trim())+"");
                     weight+=temp;
                }
                catch(Exception exp){}
            }
            else
            {
                //wrongRoutes++;
                return " No Route";
            }
        } }catch(Exception exp){}
        return weight+"";
    }    
    //==================================================================================
    //************************************  Gel ElectroPhoresis End *************************************************************
//==================================================================================
}

// Created by Godar J. Ibrahim, Year 2011
// godar.ibrahim@su.edu.krd
// godar@awrosoft.com

package dnacomputing;
//import jung.*;
import javax.swing.*;
import java.awt.*;
import java.awt.Dimension;
import edu.uci.ics.jung.visualization.decorators.*;
import edu.uci.ics.jung.algorithms.layout.*;
import edu.uci.ics.jung.graph.*;
import edu.uci.ics.jung.visualization.*;
import java.util.*;
import java.io.*;


public class mainFrame extends javax.swing.JFrame {

    schDNA DNAsch;
//===================================================================================
    public ArrayList<String> finalJobStrands= new ArrayList<String>();
    public ArrayList<String> finalJobNames= new ArrayList<String>();
    public ArrayList<Integer> finalAvgWaiting= new ArrayList<Integer>();
    public ArrayList<Integer> finalAvgTurning= new ArrayList<Integer>();
    public ArrayList<String> sortedWaits= new ArrayList<String>();
    public ArrayList<String> sortedTurns= new ArrayList<String>();
    
    String runningMode="";
    /** Creates new form mainFrame */
    String selectedTab="Four Color Map";
    int verticesNo=5,wrongRoutes=0,totalcorrectRoutes=0,correctRoutes,averageCorrectRoutes=0,routeCount=1;
    String networkTemplate="template1";
    int eDNAtype=0; // 1=PCR, 2=SSCP, 3=PCR+SSCP
    long heapSizeBeg,heapMaxSizeBeg,heapFreeSizeBeg;
    long heapSizeEnd,heapMaxSizeEnd,heapFreeSizeEnd;

    double averageShortestPath=0;
    int totalShortestPAth=0,randomSolutionFactor=5;
    String sorthestPathAll="1000";
    boolean saveReults=false; // saving results of DNA or not

    long startTime,endTime; // for calculating elapsed time

    FileWriter fstream; // writing results into output file
    BufferedWriter out;
    String resultFileName="";

    FileWriter totalStream; // writing results into output file
    BufferedWriter totalOut;

    DNA shortestPath=new DNA(); // instant object of the DNA class
     
    public mainFrame()
    {
        initComponents();       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pathButtonGroup = new javax.swing.ButtonGroup();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        buttonGroup3 = new javax.swing.ButtonGroup();
        buttonGroup4 = new javax.swing.ButtonGroup();
        buttonGroup5 = new javax.swing.ButtonGroup();
        buttonGroup6 = new javax.swing.ButtonGroup();
        mainTab = new javax.swing.JTabbedPane();
        colorTab = new javax.swing.JTabbedPane();
        colorPanel = new javax.swing.JPanel();
        colorLeftPanel = new javax.swing.JPanel();
        genMapBT = new javax.swing.JButton();
        colorRightPanel = new javax.swing.JPanel();
        scheduleTap = new javax.swing.JTabbedPane();
        schedulePanel = new javax.swing.JPanel();
        scheduleLeftPanel = new javax.swing.JPanel();
        inputSCHFileTXT = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        solutionsSCHTXT = new javax.swing.JTextPane();
        saveSCHReultsCHCK = new javax.swing.JCheckBox();
        runDNASCHBT = new javax.swing.JButton();
        runeDNASCHBT = new javax.swing.JButton();
        mutationsSCHNoTXT = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        summarySCHResultTXT = new javax.swing.JTextPane();
        schCodingBT = new javax.swing.JButton();
        runningLoopSchedTXT = new javax.swing.JTextField();
        scheduleRightPanel = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        initialDnaSCHTXT = new javax.swing.JTextPane();
        jScrollPane6 = new javax.swing.JScrollPane();
        SCHResultTXT = new javax.swing.JTextPane();
        showBasicSchedCHKBX = new javax.swing.JCheckBox();
        pathTab = new javax.swing.JTabbedPane();
        pathPanel = new javax.swing.JPanel();
        pathLeftPanel = new javax.swing.JPanel();
        generateNetBT = new javax.swing.JButton();
        clearNetBT = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        verticesTXT = new javax.swing.JTextField();
        template2 = new javax.swing.JRadioButton();
        template1 = new javax.swing.JRadioButton();
        template3 = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        edgesTXT = new javax.swing.JTextField();
        runDNAshortestPathBT = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        solutionsTXT = new javax.swing.JTextPane();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        summaryResultTXT = new javax.swing.JTextPane();
        openResultBT = new javax.swing.JButton();
        saveReultsCHCK = new javax.swing.JCheckBox();
        runeDNAshortestPathBT = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        inputFileTXT = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        mutationsNoTXT = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        ePCR = new javax.swing.JRadioButton();
        eSSCP = new javax.swing.JRadioButton();
        eBoth = new javax.swing.JRadioButton();
        eNone = new javax.swing.JRadioButton();
        resetCountersBT = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        runningLoopTXT = new javax.swing.JTextField();
        repAddStEndCHK = new javax.swing.JCheckBox();
        eVolSSCP = new javax.swing.JCheckBox();
        jPanel2 = new javax.swing.JPanel();
        jobSchedulingRadio = new javax.swing.JRadioButton();
        ShortestPathRadio = new javax.swing.JRadioButton();
        runAllBT = new javax.swing.JButton();
        runAllCHBX = new javax.swing.JCheckBox();
        didiveInitial = new javax.swing.JTextField();
        showSummCHBX = new javax.swing.JCheckBox();
        jLabel9 = new javax.swing.JLabel();
        pathRightPanel = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        shortestPathResult = new javax.swing.JTextPane();
        jScrollPane4 = new javax.swing.JScrollPane();
        initialDnaTXT = new javax.swing.JTextPane();
        showResultsCHKBX = new javax.swing.JCheckBox();
        showPCRCHBX = new javax.swing.JCheckBox();
        showSynthCHBX = new javax.swing.JCheckBox();
        outTotalCHBX = new javax.swing.JCheckBox();
        progress = new javax.swing.JProgressBar();
        showBasicInfoCHKBX = new javax.swing.JCheckBox();
        mainMenuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        openBT = new javax.swing.JMenuItem();
        exitBT = new javax.swing.JMenuItem();
        editMenu = new javax.swing.JMenu();
        copyBT = new javax.swing.JMenuItem();
        cutBT = new javax.swing.JMenuItem();
        pasteBT = new javax.swing.JMenuItem();
        toolsMenu = new javax.swing.JMenu();
        utilitiesBT = new javax.swing.JMenuItem();
        shrtestPathBT = new javax.swing.JMenuItem();
        forColorMapBT = new javax.swing.JMenuItem();
        helpMenu = new javax.swing.JMenu();
        aboutBT = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Evolutionary DNA Computing");

        mainTab.setBackground(java.awt.Color.white);
        mainTab.setBorder(new javax.swing.border.MatteBorder(null));
        mainTab.setAutoscrolls(true);
        mainTab.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                mainTabMouseClicked(evt);
            }
        });
        mainTab.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                mainTabStateChanged(evt);
            }
        });
        mainTab.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                mainTabFocusGained(evt);
            }
        });

        colorLeftPanel.setBackground(new java.awt.Color(204, 255, 255));

        genMapBT.setText("Generate Map");
        genMapBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                genMapBTActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout colorLeftPanelLayout = new javax.swing.GroupLayout(colorLeftPanel);
        colorLeftPanel.setLayout(colorLeftPanelLayout);
        colorLeftPanelLayout.setHorizontalGroup(
            colorLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(colorLeftPanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(genMapBT)
                .addContainerGap(155, Short.MAX_VALUE))
        );
        colorLeftPanelLayout.setVerticalGroup(
            colorLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(colorLeftPanelLayout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addComponent(genMapBT)
                .addContainerGap(652, Short.MAX_VALUE))
        );

        colorRightPanel.setBackground(new java.awt.Color(204, 255, 204));

        javax.swing.GroupLayout colorRightPanelLayout = new javax.swing.GroupLayout(colorRightPanel);
        colorRightPanel.setLayout(colorRightPanelLayout);
        colorRightPanelLayout.setHorizontalGroup(
            colorRightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1059, Short.MAX_VALUE)
        );
        colorRightPanelLayout.setVerticalGroup(
            colorRightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 710, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout colorPanelLayout = new javax.swing.GroupLayout(colorPanel);
        colorPanel.setLayout(colorPanelLayout);
        colorPanelLayout.setHorizontalGroup(
            colorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(colorPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(colorLeftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(1123, Short.MAX_VALUE))
            .addGroup(colorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, colorPanelLayout.createSequentialGroup()
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(colorRightPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(655, 655, 655)))
        );
        colorPanelLayout.setVerticalGroup(
            colorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(colorPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(colorLeftPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(colorPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(colorPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(colorRightPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        colorTab.addTab("...", colorPanel);

        mainTab.addTab("Four Color Map", colorTab);

        scheduleLeftPanel.setBackground(new java.awt.Color(204, 255, 255));

        inputSCHFileTXT.setText("Jobs/05-1");

        jLabel6.setText("Input File");

        jLabel7.setText("Solutions");

        solutionsSCHTXT.setText("200");
        jScrollPane7.setViewportView(solutionsSCHTXT);

        saveSCHReultsCHCK.setText("Output File");
        saveSCHReultsCHCK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveSCHReultsCHCKActionPerformed(evt);
            }
        });

        runDNASCHBT.setText("Run DNA");
        runDNASCHBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runDNASCHBTActionPerformed(evt);
            }
        });

        runeDNASCHBT.setText("Run eDNA");
        runeDNASCHBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runeDNASCHBTActionPerformed(evt);
            }
        });

        mutationsSCHNoTXT.setText("100");

        jLabel8.setText("No. of Mutations");

        jScrollPane8.setViewportView(summarySCHResultTXT);

        schCodingBT.setText("Coding");
        schCodingBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                schCodingBTActionPerformed(evt);
            }
        });

        runningLoopSchedTXT.setText("1");

        javax.swing.GroupLayout scheduleLeftPanelLayout = new javax.swing.GroupLayout(scheduleLeftPanel);
        scheduleLeftPanel.setLayout(scheduleLeftPanelLayout);
        scheduleLeftPanelLayout.setHorizontalGroup(
            scheduleLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scheduleLeftPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(scheduleLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(scheduleLeftPanelLayout.createSequentialGroup()
                        .addGap(84, 84, 84)
                        .addComponent(inputSCHFileTXT, javax.swing.GroupLayout.DEFAULT_SIZE, 166, Short.MAX_VALUE)))
                .addGap(109, 109, 109))
            .addGroup(scheduleLeftPanelLayout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addComponent(saveSCHReultsCHCK)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 99, Short.MAX_VALUE)
                .addComponent(runningLoopSchedTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(scheduleLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(runeDNASCHBT)
                    .addComponent(runDNASCHBT))
                .addGap(56, 56, 56))
            .addGroup(scheduleLeftPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(mutationsSCHNoTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(202, Short.MAX_VALUE))
            .addGroup(scheduleLeftPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 142, Short.MAX_VALUE)
                .addComponent(schCodingBT)
                .addGap(28, 28, 28))
            .addGroup(scheduleLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(scheduleLeftPanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 334, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(25, Short.MAX_VALUE)))
        );
        scheduleLeftPanelLayout.setVerticalGroup(
            scheduleLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(scheduleLeftPanelLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(scheduleLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(inputSCHFileTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(13, 13, 13)
                .addGroup(scheduleLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(schCodingBT)
                    .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGroup(scheduleLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(scheduleLeftPanelLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(scheduleLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(mutationsSCHNoTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addComponent(saveSCHReultsCHCK))
                    .addGroup(scheduleLeftPanelLayout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(scheduleLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(runDNASCHBT)
                            .addComponent(runningLoopSchedTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(runeDNASCHBT)))
                .addContainerGap(519, Short.MAX_VALUE))
            .addGroup(scheduleLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(scheduleLeftPanelLayout.createSequentialGroup()
                    .addGap(266, 266, 266)
                    .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 372, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(72, Short.MAX_VALUE)))
        );

        scheduleRightPanel.setBackground(new java.awt.Color(204, 255, 204));

        javax.swing.GroupLayout scheduleRightPanelLayout = new javax.swing.GroupLayout(scheduleRightPanel);
        scheduleRightPanel.setLayout(scheduleRightPanelLayout);
        scheduleRightPanelLayout.setHorizontalGroup(
            scheduleRightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 27, Short.MAX_VALUE)
        );
        scheduleRightPanelLayout.setVerticalGroup(
            scheduleRightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 710, Short.MAX_VALUE)
        );

        jScrollPane5.setViewportView(initialDnaSCHTXT);

        SCHResultTXT.setPreferredSize(new java.awt.Dimension(2, 20));
        jScrollPane6.setViewportView(SCHResultTXT);

        showBasicSchedCHKBX.setText("Show Basic Info");

        javax.swing.GroupLayout schedulePanelLayout = new javax.swing.GroupLayout(schedulePanel);
        schedulePanel.setLayout(schedulePanelLayout);
        schedulePanelLayout.setHorizontalGroup(
            schedulePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(schedulePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scheduleLeftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(schedulePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(schedulePanelLayout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addGroup(schedulePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5, javax.swing.GroupLayout.DEFAULT_SIZE, 955, Short.MAX_VALUE)
                            .addComponent(jScrollPane6, javax.swing.GroupLayout.DEFAULT_SIZE, 955, Short.MAX_VALUE)))
                    .addGroup(schedulePanelLayout.createSequentialGroup()
                        .addGap(90, 90, 90)
                        .addComponent(showBasicSchedCHKBX)))
                .addContainerGap())
            .addGroup(schedulePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(schedulePanelLayout.createSequentialGroup()
                    .addGap(298, 298, 298)
                    .addComponent(scheduleRightPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(1087, Short.MAX_VALUE)))
        );
        schedulePanelLayout.setVerticalGroup(
            schedulePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(schedulePanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(schedulePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(scheduleLeftPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(schedulePanelLayout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(46, 46, 46)
                        .addComponent(showBasicSchedCHKBX)
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
            .addGroup(schedulePanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(schedulePanelLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(scheduleRightPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );

        scheduleTap.addTab("...", schedulePanel);

        mainTab.addTab("Scheduling", scheduleTap);

        pathPanel.setAutoscrolls(true);

        pathLeftPanel.setBackground(new java.awt.Color(204, 255, 255));

        generateNetBT.setText("Generate");
        generateNetBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generateNetBTActionPerformed(evt);
            }
        });

        clearNetBT.setText("Clear");
        clearNetBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearNetBTActionPerformed(evt);
            }
        });

        jLabel1.setText("Vertices");

        verticesTXT.setText("6");

        pathButtonGroup.add(template2);
        template2.setText("Template-2");
        template2.setToolTipText("Shortest Path");
        template2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                template2MouseClicked(evt);
            }
        });

        pathButtonGroup.add(template1);
        template1.setText("Template-1");
        template1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                template1MouseClicked(evt);
            }
        });

        pathButtonGroup.add(template3);
        template3.setText("Template-3");

        jLabel2.setText("Edges");

        edgesTXT.setText("9");

        runDNAshortestPathBT.setText("Run DNA");
        runDNAshortestPathBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runDNAshortestPathBTActionPerformed(evt);
            }
        });

        solutionsTXT.setText("200");
        jScrollPane2.setViewportView(solutionsTXT);

        jLabel3.setText("Solutions");

        jScrollPane3.setViewportView(summaryResultTXT);

        openResultBT.setText("Open Result...");
        openResultBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                openResultBTActionPerformed(evt);
            }
        });

        saveReultsCHCK.setText("Output File");
        saveReultsCHCK.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveReultsCHCKActionPerformed(evt);
            }
        });

        runeDNAshortestPathBT.setText("Run eDNA");
        runeDNAshortestPathBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runeDNAshortestPathBTActionPerformed(evt);
            }
        });

        jLabel4.setText("Input File");

        inputFileTXT.setText("Networks/010-1.txt");

        jLabel5.setText("No. of crossOvers");

        mutationsNoTXT.setText("100");

        jPanel1.setBackground(new java.awt.Color(204, 204, 204));

        buttonGroup1.add(ePCR);
        ePCR.setText("PCR");
        ePCR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ePCRActionPerformed(evt);
            }
        });

        buttonGroup1.add(eSSCP);
        eSSCP.setText("SSCP");
        eSSCP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eSSCPActionPerformed(evt);
            }
        });

        buttonGroup1.add(eBoth);
        eBoth.setText("Both");
        eBoth.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eBothActionPerformed(evt);
            }
        });

        buttonGroup1.add(eNone);
        eNone.setSelected(true);
        eNone.setText("None");
        eNone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eNoneActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ePCR)
                .addGap(18, 18, 18)
                .addComponent(eSSCP)
                .addGap(18, 18, 18)
                .addComponent(eBoth)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 11, Short.MAX_VALUE)
                .addComponent(eNone)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ePCR)
                    .addComponent(eSSCP)
                    .addComponent(eBoth)
                    .addComponent(eNone))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        resetCountersBT.setText("Reset");
        resetCountersBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetCountersBTActionPerformed(evt);
            }
        });

        jButton1.setText("Coding");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        runningLoopTXT.setText("1");

        repAddStEndCHK.setText("RepAdd SE");

        eVolSSCP.setText("Evol SSCP");

        buttonGroup6.add(jobSchedulingRadio);
        jobSchedulingRadio.setText("JS");
        jobSchedulingRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jobSchedulingRadioActionPerformed(evt);
            }
        });

        buttonGroup6.add(ShortestPathRadio);
        ShortestPathRadio.setSelected(true);
        ShortestPathRadio.setText("SP");
        ShortestPathRadio.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ShortestPathRadioActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(ShortestPathRadio)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jobSchedulingRadio)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ShortestPathRadio)
                    .addComponent(jobSchedulingRadio))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        runAllBT.setText("Run All");
        runAllBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                runAllBTActionPerformed(evt);
            }
        });

        runAllCHBX.setText("Run All");

        didiveInitial.setText("3");

        showSummCHBX.setSelected(true);
        showSummCHBX.setText("Show Sum");

        jLabel9.setText("Solutions /");

        javax.swing.GroupLayout pathLeftPanelLayout = new javax.swing.GroupLayout(pathLeftPanel);
        pathLeftPanel.setLayout(pathLeftPanelLayout);
        pathLeftPanelLayout.setHorizontalGroup(
            pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pathLeftPanelLayout.createSequentialGroup()
                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pathLeftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 443, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pathLeftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(inputFileTXT, javax.swing.GroupLayout.DEFAULT_SIZE, 388, Short.MAX_VALUE))
                            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pathLeftPanelLayout.createSequentialGroup()
                                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                                    .addComponent(jLabel5)
                                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pathLeftPanelLayout.createSequentialGroup()
                                                    .addComponent(jLabel9)
                                                    .addGap(13, 13, 13)))
                                            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                                .addComponent(jLabel3)
                                                .addGap(18, 18, 18)))
                                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addComponent(mutationsNoTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 84, Short.MAX_VALUE)
                                                .addComponent(runningLoopTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addGap(107, 107, 107))
                                            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                                .addComponent(didiveInitial, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                                .addComponent(runAllCHBX)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                                .addComponent(jButton1))
                                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pathLeftPanelLayout.createSequentialGroup()
                                                .addComponent(runeDNAshortestPathBT)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(runDNAshortestPathBT))))
                                    .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                        .addComponent(showSummCHBX)
                                        .addGap(18, 18, 18)
                                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                                .addGap(10, 10, 10)
                                                .addComponent(openResultBT)
                                                .addGap(146, 146, 146)
                                                .addComponent(resetCountersBT)))))
                                .addGap(16, 16, 16))))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, pathLeftPanelLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(repAddStEndCHK)
                            .addComponent(eVolSSCP))
                        .addGap(255, 255, 255))
                    .addGroup(pathLeftPanelLayout.createSequentialGroup()
                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(generateNetBT)
                                    .addComponent(template1))
                                .addGap(18, 18, 18)
                                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                        .addComponent(template2)
                                        .addGap(18, 18, 18)
                                        .addComponent(template3))
                                    .addComponent(clearNetBT)))
                            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(jLabel1)
                                .addGap(9, 9, 9)
                                .addComponent(verticesTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(23, 23, 23)
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(edgesTXT, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(126, 126, 126)))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pathLeftPanelLayout.createSequentialGroup()
                .addContainerGap(281, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(81, 81, 81))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pathLeftPanelLayout.createSequentialGroup()
                .addContainerGap(312, Short.MAX_VALUE)
                .addComponent(runAllBT)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(saveReultsCHCK)
                .addGap(5, 5, 5))
        );
        pathLeftPanelLayout.setVerticalGroup(
            pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(template1)
                    .addComponent(template2)
                    .addComponent(template3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(generateNetBT)
                    .addComponent(clearNetBT))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(verticesTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(edgesTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(4, 4, 4)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(inputFileTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pathLeftPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(runAllBT)
                            .addComponent(saveReultsCHCK))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 12, Short.MAX_VALUE))
                    .addGroup(pathLeftPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(didiveInitial, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jButton1)
                        .addComponent(runAllCHBX))
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pathLeftPanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(mutationsNoTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pathLeftPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(runeDNAshortestPathBT)
                            .addComponent(runDNAshortestPathBT)
                            .addComponent(runningLoopTXT, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pathLeftPanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(pathLeftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(pathLeftPanelLayout.createSequentialGroup()
                                .addComponent(repAddStEndCHK)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(eVolSSCP)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(showSummCHBX))
                            .addComponent(resetCountersBT)))
                    .addGroup(pathLeftPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(openResultBT)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 343, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pathRightPanel.setBackground(new java.awt.Color(204, 255, 204));
        pathRightPanel.setAutoscrolls(true);

        shortestPathResult.setPreferredSize(new java.awt.Dimension(2, 20));
        jScrollPane1.setViewportView(shortestPathResult);

        jScrollPane4.setViewportView(initialDnaTXT);

        showResultsCHKBX.setText("Show Random Solutions");

        showPCRCHBX.setText("Show PCR Results");

        showSynthCHBX.setText("Show Synthesized Results");

        outTotalCHBX.setText("Output Totals");

        showBasicInfoCHKBX.setText("Show Basic Info");

        javax.swing.GroupLayout pathPanelLayout = new javax.swing.GroupLayout(pathPanel);
        pathPanel.setLayout(pathPanelLayout);
        pathPanelLayout.setHorizontalGroup(
            pathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pathPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pathLeftPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(pathRightPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(pathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pathPanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(showBasicInfoCHKBX)
                        .addGap(30, 30, 30)
                        .addComponent(showResultsCHKBX)
                        .addGap(18, 18, 18)
                        .addComponent(showPCRCHBX)
                        .addGap(18, 18, 18)
                        .addComponent(showSynthCHBX)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(outTotalCHBX)
                        .addGap(198, 198, 198))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pathPanelLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(pathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(progress, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 744, Short.MAX_VALUE)
                            .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 744, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 744, Short.MAX_VALUE))
                        .addGap(135, 135, 135))))
        );
        pathPanelLayout.setVerticalGroup(
            pathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pathPanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(pathRightPanel, javax.swing.GroupLayout.DEFAULT_SIZE, 710, Short.MAX_VALUE)
                    .addComponent(pathLeftPanel, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(pathPanelLayout.createSequentialGroup()
                        .addComponent(progress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(26, 26, 26)
                        .addGroup(pathPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(outTotalCHBX)
                            .addComponent(showResultsCHKBX)
                            .addComponent(showPCRCHBX)
                            .addComponent(showSynthCHBX)
                            .addComponent(showBasicInfoCHKBX))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 362, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pathTab.addTab("...", pathPanel);

        mainTab.addTab("Shortest Path", pathTab);

        fileMenu.setText("File");
        fileMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fileMenuActionPerformed(evt);
            }
        });

        openBT.setText("Open..");
        fileMenu.add(openBT);

        exitBT.setText("Exit");
        exitBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitBTMouseClicked(evt);
            }
        });
        exitBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitBTActionPerformed(evt);
            }
        });
        fileMenu.add(exitBT);

        mainMenuBar.add(fileMenu);

        editMenu.setText("Edit");

        copyBT.setText("Copy");
        editMenu.add(copyBT);

        cutBT.setText("Cut");
        editMenu.add(cutBT);

        pasteBT.setText("Paste");
        editMenu.add(pasteBT);

        mainMenuBar.add(editMenu);

        toolsMenu.setText("Tools");

        utilitiesBT.setText("Utilities...");
        utilitiesBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                utilitiesBTActionPerformed(evt);
            }
        });
        toolsMenu.add(utilitiesBT);

        shrtestPathBT.setText("SP...");
        shrtestPathBT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                shrtestPathBTMouseClicked(evt);
            }
        });
        shrtestPathBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shrtestPathBTActionPerformed(evt);
            }
        });
        toolsMenu.add(shrtestPathBT);

        forColorMapBT.setText("FCM...");
        forColorMapBT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                forColorMapBTActionPerformed(evt);
            }
        });
        toolsMenu.add(forColorMapBT);

        mainMenuBar.add(toolsMenu);

        helpMenu.setText("Help");

        aboutBT.setText("About");
        helpMenu.add(aboutBT);

        mainMenuBar.add(helpMenu);

        setJMenuBar(mainMenuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(mainTab, javax.swing.GroupLayout.PREFERRED_SIZE, 1424, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(424, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(mainTab, javax.swing.GroupLayout.DEFAULT_SIZE, 790, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
//===================================================================================
    private void fileMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fileMenuActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_fileMenuActionPerformed
//===================================================================================
    private void exitBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitBTMouseClicked
        // TODO add your handling code here:
        // try{ totalOut.close();}catch(Exception e){Utilities.showMessage(e.getMessage(), "Exception");}
        System.exit(1);
    }//GEN-LAST:event_exitBTMouseClicked
//===================================================================================
    private void exitBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitBTActionPerformed
        // TODO add your handling code here:
        dispose();
        System.exit(1);
    }//GEN-LAST:event_exitBTActionPerformed
//===================================================================================//===================================================================================//===================================================================================//===================================================================================//===================================================================================//===================================================================================
    private void getVerticesNum() // get the number of vertices set by user
    {
        try
        {
           verticesNo = Integer.parseInt(verticesTXT.getText());
        }
        catch (NumberFormatException nfe)
        {

        } 
    }
    //===================================================================================    //===================================================================================
    private void generateShortestPath() // generate SP network & put on the panel
    {
        shortestPath network=new shortestPath(verticesTXT.getText(),edgesTXT.getText());
        JScrollPane scrollPane = new JScrollPane(network);
        pathRightPanel.add(scrollPane,network);
        pathRightPanel.revalidate();
        pathRightPanel.repaint();
    }
     //===================================================================================
    private void generateEdgeLables()
    {
        /*EdgeLabel edge=new EdgeLabel();
        pathRightPanel.add(edge);
        pathRightPanel.revalidate();
        pathRightPanel.repaint(); */
    }
    //===================================================================================//===================================================================================//===================================================================================//===================================================================================
    private void utilitiesBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_utilitiesBTActionPerformed
        // TODO add your handling code here:
        utilitiesForm utilitiesFRM=new utilitiesForm();
        utilitiesFRM.setLocationRelativeTo(null); // centering
        utilitiesFRM.show();
    }//GEN-LAST:event_utilitiesBTActionPerformed

    private void shrtestPathBTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_shrtestPathBTMouseClicked
        // TODO add your handling code here:
        shortestPathFRM shoretstPathForm=new shortestPathFRM();
        shoretstPathForm.show();
    }//GEN-LAST:event_shrtestPathBTMouseClicked

    private void shrtestPathBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shrtestPathBTActionPerformed
        
        JFrame shortestPathFrame=new JFrame();
        shortestPathFrame.setSize(1000, 900);
        shortestPath shortestPathPanle=new shortestPath(verticesTXT.getText(),edgesTXT.getText());

        shortestPathFrame.add(shortestPathPanle);
        shortestPathFrame.validate();
        shortestPathFrame.show();
    }//GEN-LAST:event_shrtestPathBTActionPerformed

    private void forColorMapBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_forColorMapBTActionPerformed
        // TODO add your handling code here:
        ClusteringFrame clusterFrame=new ClusteringFrame();
        clusterFrame.show();
    }//GEN-LAST:event_forColorMapBTActionPerformed

private void mainTabFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_mainTabFocusGained
        //Utilities.showMessage(evt.getID()+"", "Tab Changed");
}//GEN-LAST:event_mainTabFocusGained

private void mainTabStateChanged(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_mainTabStateChanged
        // TODO add your handling code here:
       //Utilities.showMessage("", "Tab Changed");
}//GEN-LAST:event_mainTabStateChanged

private void mainTabMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_mainTabMouseClicked
        JTabbedPane pane = (JTabbedPane)evt.getSource();

        // Get current tab
        int sel = pane.getSelectedIndex();
        selectedTab=pane.getTitleAt(sel);
        //Utilities.showMessage(selectedTab+" selected", "Tab Changed");
}//GEN-LAST:event_mainTabMouseClicked

private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        initializeOperation(false);
}//GEN-LAST:event_jButton1ActionPerformed

private void resetCountersBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetCountersBTActionPerformed
        // TODO add your handling code here:
        totalcorrectRoutes=0;
        routeCount=0;
}//GEN-LAST:event_resetCountersBTActionPerformed

private void eNoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eNoneActionPerformed
// TODO add your handling code here:
    eDNAtype=0;
}//GEN-LAST:event_eNoneActionPerformed

private void eBothActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eBothActionPerformed
// TODO add your handling code here:
    eDNAtype=3;
}//GEN-LAST:event_eBothActionPerformed

private void eSSCPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eSSCPActionPerformed
// TODO add your handling code here:
    eDNAtype=2;
}//GEN-LAST:event_eSSCPActionPerformed

private void ePCRActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ePCRActionPerformed
// TODO add your handling code here:
    eDNAtype=1;
}//GEN-LAST:event_ePCRActionPerformed

private void runeDNAFunction()
{
    for(int i=0;i<Integer.parseInt(runningLoopTXT.getText());i++) 
    {
          //shortestPath.resetAllCounters();
          runDNAforShortestPath(true);
          progress.setValue(i+1);
          routeCount++;
          totalcorrectRoutes+=correctRoutes;
          averageCorrectRoutes=totalcorrectRoutes/routeCount;
     }
}

private void runDNAFunction()
{
    for(int i=0;i<Integer.parseInt(runningLoopTXT.getText());i++)
    {
        //shortestPath.resetAllCounters();
        runDNAforShortestPath(false);
        progress.setValue(i+1);                 
        routeCount++;        
        totalcorrectRoutes+=correctRoutes;
        averageCorrectRoutes=totalcorrectRoutes/routeCount;
    }
}

private void runAlleDNA()
{
     try{
           File file = new File("D:/Postgraduate Studying/My Thesis/Practical Project/DNAcomputing/src/dnacomputing/Networks");  
            File[] files = file.listFiles();  
          for (int fileInList = 0; fileInList < files.length; fileInList++)  
          {  
                 inputFileTXT.setText("/Networks/"+new File(files[fileInList].toString()).getName());
                 try{sleep(500);}catch(Exception exp){}
                 
                 initializeOperation(false);     
                 
                  // 0- Normal DNA     
                 setParameters(false,false);
                 eDNAtype=0;
                 runDNAFunction();
                 sleep(500);
                 
                // 1- RepAdd        
                setParameters(true,false); 
                eDNAtype=0;
                runeDNAFunction();
                sleep(500);

                // 2- PCR Cross
                setParameters(false,false);        
                eDNAtype=1;
                runeDNAFunction();
                sleep(500);

                // 3- SSCP Cross
                setParameters(false,false);        
                eDNAtype=2;              
                runeDNAFunction();
                sleep(500);

                // 4- PCR+SSCP Cross
                setParameters(false,false);        
                eDNAtype=3;
                runeDNAFunction();
                sleep(500);

                 // 5- PCR+RepAdd
                setParameters(true,false);        
                eDNAtype=1;
                runeDNAFunction();
                sleep(500);

                 // 6- SSCP+RepAdd
                setParameters(true,false);        
                eDNAtype=2;
                runeDNAFunction();
                sleep(500);

                 // 7- PCR+SSCP+RepAdd
                setParameters(true,false);        
                eDNAtype=3;
                runeDNAFunction();
                sleep(500);

                // 8- evolSSCP
                setParameters(false,true);        
                eDNAtype=0;
                runeDNAFunction();
                sleep(500);

                // 9- evolSSCP+PCR Cross
                setParameters(false,true);        
                eDNAtype=1;
                runeDNAFunction();
                sleep(500);

                // 10- evolSSCP+SSCP Cross
                setParameters(false,true);        
                eDNAtype=2;
                runeDNAFunction();
                sleep(500);

                // 11- evolSSCP+SSCP Cross
                setParameters(false,true);        
                eDNAtype=3;
                runeDNAFunction();
                sleep(500);

                // 12- evolSSCP+RepAdd
                setParameters(true,true);        
                eDNAtype=0;
                runeDNAFunction();
                sleep(500);

                // 13- evolSSCP+RepAdd
                setParameters(true,true);        
                eDNAtype=3;
                runeDNAFunction();
                sleep(500);
        }  
    }catch(Exception exp){Utilities.showMessage(exp.getMessage(), selectedTab);}
}
private void runeDNAshortestPathBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runeDNAshortestPathBTActionPerformed

        //if(runAllCHBX.isSelected())
           // runAlleDNA();
        //else
        {
            ressetCounters();
             new runeDNA().start();
        }
            
        
}//GEN-LAST:event_runeDNAshortestPathBTActionPerformed

private void setParameters(boolean repAdd, boolean evolSSCP)
{
    ressetCounters();
    repAddStEndCHK.setSelected(repAdd);
    eVolSSCP.setSelected(evolSSCP);     
}
private void ressetCounters()
{
        routeCount=1;
        averageShortestPath=0;
        totalShortestPAth=0;
        totalcorrectRoutes=0;
        correctRoutes=0;
        sorthestPathAll="1000";
        setProgress();
}
private void saveReultsCHCKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveReultsCHCKActionPerformed
        
}//GEN-LAST:event_saveReultsCHCKActionPerformed

private void openResultBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_openResultBTActionPerformed

        try
        {
            String program = "c:\\Program~1\\Windows~1\\Accessories\\wordpad.exe\"";
            Runtime load = Runtime.getRuntime();
            load.exec(program + " " + resultFileName);
        }catch(Exception exp){ Utilities.showMessage(exp.getMessage(), "Opening File - Problem");}
}//GEN-LAST:event_openResultBTActionPerformed

private void runDNAshortestPathBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runDNAshortestPathBTActionPerformed
            
        routeCount=1;
        averageShortestPath=0;
        totalShortestPAth=0;
        totalcorrectRoutes=0;
        correctRoutes=0;
        sorthestPathAll="1000";
        setProgress();
        new runDNA().start();        
}//GEN-LAST:event_runDNAshortestPathBTActionPerformed

private void template1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_template1MouseClicked
        networkTemplate="template1";
}//GEN-LAST:event_template1MouseClicked

private void template2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_template2MouseClicked
        networkTemplate="template2";
}//GEN-LAST:event_template2MouseClicked

private void clearNetBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clearNetBTActionPerformed
       this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        clearNetwork();
        this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
}//GEN-LAST:event_clearNetBTActionPerformed

private void generateNetBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generateNetBTActionPerformed
        // TODO add your handling code here:
        pathRightPanel.setSize(500, 100);
        pathRightPanel.validate();

        shortestPathResult.setSize(100, 10);        
        shortestPathResult.validate();
        
        this.validate();
        this.repaint();
                
        clearNetwork();
        getVerticesNum();

        if(networkTemplate.equals("template1"))
            generateNetwork();
        else if(networkTemplate.equals("template2"))
             generateShortestPath();
         else if(networkTemplate.equals("template3"))
             generateEdgeLables();
}//GEN-LAST:event_generateNetBTActionPerformed

private void runeDNASCHBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runeDNASCHBTActionPerformed
        // TODO add your handling code here:
}//GEN-LAST:event_runeDNASCHBTActionPerformed

private void runDNASCHBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runDNASCHBTActionPerformed
        // TODO add your handling code here:
        DNAsch=new schDNA();
        DNAsch.initializae(inputSCHFileTXT.getText());
}//GEN-LAST:event_runDNASCHBTActionPerformed

private void saveSCHReultsCHCKActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveSCHReultsCHCKActionPerformed
        // TODO add your handling code here:
}//GEN-LAST:event_saveSCHReultsCHCKActionPerformed

private void genMapBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_genMapBTActionPerformed
        // TODO add your handling code here:
        generateMap();
}//GEN-LAST:event_genMapBTActionPerformed

private void schCodingBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_schCodingBTActionPerformed
// TODO add your handling code here:
   
}//GEN-LAST:event_schCodingBTActionPerformed
    
    private void runAllBTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_runAllBTActionPerformed
        // TODO add your handling code here:
        //first run the normall dna and then eDNA for 13 different modes
        runAlleDNA();
        
    }//GEN-LAST:event_runAllBTActionPerformed

    private void ShortestPathRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ShortestPathRadioActionPerformed
        // TODO add your handling code here:
        inputFileTXT.setText("Networks/010-1.txt");
    }//GEN-LAST:event_ShortestPathRadioActionPerformed

    private void jobSchedulingRadioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jobSchedulingRadioActionPerformed
        // TODO add your handling code here:
        inputFileTXT.setText("Jobs/010-1.txt");
    }//GEN-LAST:event_jobSchedulingRadioActionPerformed
//==========================================================================================
    private void resetSounters()
    {
        routeCount=1;
        averageShortestPath=0;
        totalShortestPAth=0;
        totalcorrectRoutes=0;
        correctRoutes=0;
        sorthestPathAll="1000";
    }
    //==========================================================================================//===================================================================================
    private void addToSummarySched(String text)
    {
        summarySCHResultTXT.setText(summarySCHResultTXT.getText()+text+"\n");
    }    
    //==========================================================================================
    private void prepareOperation(String fileBegin)
    {
        if(saveReultsCHCK.isSelected())
        try
        {
            resultFileName=fileBegin+getFileStamp()+".txt";
            fstream= new FileWriter(resultFileName);
            out= new BufferedWriter(fstream);
        }catch(Exception e){Utilities.showMessage(e.getMessage(), "Read File Exception");}

        shortestPathResult.removeAll();
        summaryResultTXT.removeAll();
        summaryResultTXT.setText("");
        shortestPathResult.setText("Running DNA Algorithm:\n");
        writeToFile("Running DNA Algorithm:\n","");
    }
    //==========================================================================================
    private void initializeOperation(boolean evolutionary) // true=evolutionary
    {
        summaryResultTXT.setText("");
        //********************* First Step *************************************************************************************
        if(!evolutionary)
         shortestPath.initializae(inputFileTXT.getText()); //Steps: 1-Watson-Crick Pairing, 2-Polymerase, 3-Ligase, 4-Restriction Enzymes
        // get the contents of the input file, line by line
        // returns distinct Nodes and save Edges & Edge Weights
        // returns generated random Strand for Nodes and save them in Test Tube
        // returns strands of edges and save them in Test Tube

        showVerticesStrands(shortestPath.verticesStrands,shortestPath.distinctVertices,
                        shortestPath.compVerticesStrands,shortestPath.revesredCompVerticesStrands);
        showEdgesStrands(shortestPath.edgeStrandsHash,shortestPath.edges,shortestPath.edgeWeights);
        showItem("Test Tube Contents",shortestPath.testTube);
    }
    //==========================================================================================
    private void randomSolutionOperation()
    {
        //********************* Second Step *************************************************************************************
        shortestPath.generateRandomSolutiuons(Integer.parseInt(solutionsTXT.getText()));
        if(showResultsCHKBX.isSelected())
            showItem("Random Solution",shortestPath.randomSolutions);

        addToSummary("Random Solutions= "+shortestPath.randomSolutions.size());
    }
    //==========================================================================================
    private void pcrOperation(boolean evolutionary)
    {
        //********************* Third Step *************************************************************************************
        if(jobSchedulingRadio.isSelected())
            shortestPath.dnaPCRSchedule();
        else
        {
            if(evolutionary)
                shortestPath.ednaPCR(repAddStEndCHK.isSelected(),eDNAtype,mutationsNoTXT.getText());
            else
                shortestPath.dnaPCR();
        }
        if(showPCRCHBX.isSelected())
        {
            showItem("PCR Solutions",shortestPath.pcrSolutions);
            showItem("PCR Node Paths",shortestPath.pcrRealSolutions);
        }
        addToSummary("PCR Solutions= "+shortestPath.pcrSolutions.size());
    }    
    //==========================================================================================
    private void sscpOperation(boolean evolutionary)
    {
        //********************* Fifth Step *************************************************************************************
        //if(evolutionary && jobSchedulingRadio.isSelected())
          //  shortestPath.esscpSchedule(eVolSSCP.isSelected(),eDNAtype,mutationsNoTXT.getText());
        if(evolutionary)
            shortestPath.esscp(jobSchedulingRadio.isSelected(),eVolSSCP.isSelected(),eDNAtype,mutationsNoTXT.getText());
        else
            shortestPath.sscp();        
      
        if(showSynthCHBX.isSelected())
        {
            showItem("SSCPed Solutions",shortestPath.sscpSolutions);
            showItem("SSCPed Node Paths",shortestPath.sscpRealSolutions);
        }
         addToSummary("SSCPed Solutions= "+shortestPath.sscpSolutions.size());
         
         
         
    }
    //==========================================================================================
    private void gelOperation()
    {
        //********************* Last Step *************************************************************************************
        try{
        shortestPath.gelElectroPhoresis();
        showItemHash("SSCPed Paths Weights",shortestPath.sythWeights,shortestPath.weightedRealSolutions);
        showItemHash("All Routes",shortestPath.gelWeights,shortestPath.weightedRealSolutions);
        //addToSummary("Wrong Routes= "+(shortestPath.wrongRoutes-(shortestPath.sscpSolutions.size()-shortestPath.gelWeights.size())));
        addToSummary("Wrong Routes= "+wrongRoutes);
        correctRoutes=shortestPath.gelWeights.size()-wrongRoutes;
        addToSummary("Correct Routes= "+correctRoutes);
        addToSummary("Average Correct Routes= "+averageCorrectRoutes);
        if(shortestPath.weights.size()>0)
        {
            addToSummary("Current Shortest Route= "+shortestPath.weights.get(0));
            
            if((Integer.parseInt(shortestPath.weights.get(0)+""))<Integer.parseInt(sorthestPathAll) && !(shortestPath.weights.get(0)+"").trim().startsWith("No"))
                sorthestPathAll=shortestPath.weights.get(0)+"";
            
            addToSummary("Shortest Route: "+sorthestPathAll);
            
            averageShortestPath=((totalShortestPAth+=Integer.parseInt(shortestPath.weights.get(0)+""))/routeCount);
            
        }
        else
            addToSummary("Current Shortest Route= No Route");
        
        addToSummary("Average Route= "+averageShortestPath);
        
        }catch(Exception exp){}
    }
    //===================================================================================
    private void writeSummaries(boolean evolutionary)
    {
        try
        {
        addToSummary("----------------------------------------------------------");
        endTime = System.currentTimeMillis();
        addToSummary("Iterations= "+shortestPath.annealingIterations);
         if(evolutionary)
         {
            addToSummary("Initial PCR Drops= "+shortestPath.initilaDropedPCR);
            addToSummary("PCR CrossOvers= "+shortestPath.pcrMutations);
            addToSummary("ePCR Solutions= "+shortestPath.ePCRgenerated);
            addToSummary("");
            addToSummary("Initial SSCP Drops= "+shortestPath.initialDropedsscp);
            addToSummary("SSCP CrossOvers= "+shortestPath.sscpMutations);
            addToSummary("eSSCP Solutions= "+shortestPath.eSscpGenerated);
        }
        addToSummary("-------");
        addToSummary("Initializtion Period= "+shortestPath.initializePeriod);
        addToSummary("Random Solution Period= "+shortestPath.randomSolPeriod);        
        addToSummary("PCR Period= "+shortestPath.pcrPeriod);
        addToSummary("SSCP Period= "+shortestPath.sscpPeriod);
        addToSummary("Gel Period= "+shortestPath.gelPeriod);
        addToSummary("Total DNA Period= "+(shortestPath.otherPeriod+
                shortestPath.sscpPeriod+shortestPath.pcrPeriod+
                shortestPath.randomSolPeriod+shortestPath.initializePeriod));
        addToSummary("Total Running Time= "+(endTime-startTime)/1000F);

        writeToFile("Iterations",shortestPath.annealingIterations+"\n");
        writeToFile("Nodes",shortestPath.distinctVertices.size()+"\n");
        writeToFile("Edges",shortestPath.edges.size()+"\n");
        writeToFile("Random Solutions",shortestPath.randomSolutions.size()+"\n");
        writeToFile("PCR Solutions",shortestPath.pcrSolutions.size()+"\n");
        writeToFile("SSCPed Solutions",shortestPath.sscpSolutions.size()+"\n");
        writeToFile("SSCPed Paths Weights",shortestPath.weightedRealSolutions.size()+"\n");
        writeToFile("Wrong Routes",shortestPath.wrongRoutes+"\n");
        writeToFile("Correct Routes",correctRoutes+"\n");
        writeToFile("Current Shortest Route",shortestPath.weights.get(0)+"\n"); // new added
        writeToFile("Shortest Route",sorthestPathAll+"\n"); // new added
        
        if(evolutionary)
        {
            writeToFile("Initial PCR Drops",shortestPath.initilaDropedPCR+"\n");
            writeToFile("PCR CrossOvers",shortestPath.pcrMutations+"\n");
            writeToFile("ePCR Solutions",shortestPath.ePCRgenerated+"\n");
            writeToFile("Initial SSCP Drops",shortestPath.initialDropedsscp+"\n");
            writeToFile("SSCP CrossOvers",shortestPath.sscpMutations+"\n");
            writeToFile("eSSCP Solutions",shortestPath.eSscpGenerated+"\n");
        }
        
        writeToFile("Initializtion Period",shortestPath.initializePeriod+"\n");
        writeToFile("Random Solution Period",shortestPath.randomSolPeriod+"\n");
        writeToFile("PCR Period",shortestPath.pcrPeriod+"\n");
        writeToFile("sscp Period",shortestPath.sscpPeriod+"\n");
        writeToFile("Other Period",shortestPath.otherPeriod+"\n");
        writeToFile("Total DNA Period",(shortestPath.otherPeriod+
                shortestPath.sscpPeriod+shortestPath.pcrPeriod+
                shortestPath.randomSolPeriod+shortestPath.initializePeriod)+"\n");
        writeToFile("Total Running Time",((endTime-startTime)/1000F)+"\n");
        writeToFile("Heap Size",(heapSizeBeg-heapSizeEnd)+"\n");
        writeToFile("Heap Max Size",(heapMaxSizeBeg-heapMaxSizeEnd)+"\n");
        writeToFile("Memory Usage",(heapFreeSizeBeg-heapFreeSizeEnd)+"\n");
        
        }catch(Exception exp){}
        //summaryResultTXT.validate();
        //pathLeftPanel.revalidate();
        pathPanel.revalidate();
         try{
                sleep(500);}catch(Exception exp){}
    }
    //==========================================================================================
    private void showAllJobs()
    {
        summaryResultTXT.setText(summaryResultTXT.getText()+"All Jobs:\n");
        for(int i=0;i<finalJobNames.size();i++)
            summaryResultTXT.setText(summaryResultTXT.getText()+(i+1)+"--- "+finalJobNames.get(i)
                    +" (W="+finalAvgWaiting.get(i) +") - (T="+finalAvgTurning.get(i) +")\n");
         
    }
     //==========================================================================================
    private void copyList(ArrayList from, ArrayList to)
    {
        to.clear();
        for(int i=0;i<from.size();i++)
            to.add(from.get(i)+"");
    }
    //==========================================================================================
    private void calculateJobWaitsTurns()
    {
        Enumeration e = shortestPath.sythWeights.keys();
        
        finalJobStrands.clear();
        finalJobNames.clear();
        finalAvgWaiting.clear();
        finalAvgTurning.clear();
        sortedWaits.clear();
        sortedTurns.clear();
        
        String nextElemenet="";
        while( e. hasMoreElements() )
        {
            nextElemenet=e.nextElement()+""; // the strand of the solution
            finalJobStrands.add(nextElemenet);
            finalJobNames.add(shortestPath.getJobName(nextElemenet));
            finalAvgWaiting.add(Integer.parseInt(calcAvgWait(shortestPath.getJobName(nextElemenet))));
            finalAvgTurning.add(Integer.parseInt(calcAvgTurn(shortestPath.getJobName(nextElemenet))));
         }
        copyList(finalAvgWaiting,sortedWaits);
        copyList(finalAvgTurning,sortedTurns);
        
        Collections.sort(sortedWaits);
        Collections.sort(sortedTurns);
    }
    //==========================================================================================
    private String calcAvgWait(String jobList)
    {
        int totalWait=0,i=0;  
        String[] jobNames=jobList.split("-");
        for(i=1;i<jobNames.length-1;i++) // first and last job wait not calculated
          totalWait+=(Integer.parseInt(shortestPath.jobWeights.get(jobNames[i])+""));
        
        //return (totalWait/(i))+"";
        return totalWait+"";
    }
    //==========================================================================================
    private String calcAvgTurn(String jobList)
    {
        int totalTurn=0,i=0;  
        String[] jobNames=jobList.split("-");
        for(i=1;i<jobNames.length;i++) // first and last job wait not calculated
          totalTurn+=(Integer.parseInt(shortestPath.jobWeights.get(jobNames[i])+""));
        
        //return (totalTurn/(i))+"";
        return totalTurn+"";
    }
    //==========================================================================================
    private void showAllRoutes()
    {
        summaryResultTXT.setText(summaryResultTXT.getText()+"All Routes:\n");
        Enumeration e = shortestPath.weightedRealSolutions.keys();
        int i=1; String nextElemenet="";
        while( e. hasMoreElements() )
        {
            nextElemenet=e.nextElement()+"";
            summaryResultTXT.setText(summaryResultTXT.getText()+(i++)+"-("+shortestPath.weightedRealSolutions.get(nextElemenet)+"):  "+shortestPath.sythWeights.get(nextElemenet)+"\n");
         }
        
       /*
        for(int i=0;i<shortestPath.weights.size();i++)
        {
            summaryResultTXT.setText(summaryResultTXT.getText()+shortestPath.weights.get(i)+", ");
        }*/
    }
    //==========================================================================================
    private void getEndMemory()
    {
         //heapSizeEnd = Runtime.getRuntime().totalMemory();
         //heapMaxSizeEnd = Runtime.getRuntime().maxMemory();
         heapFreeSizeEnd = (Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())/1024;
    }
    //==========================================================================================
    private void getBeginMemory()
    {         
         //heapSizeBeg = Runtime.getRuntime().totalMemory();
         //heapMaxSizeBeg = Runtime.getRuntime().maxMemory();
         heapFreeSizeBeg = (Runtime.getRuntime().totalMemory()-Runtime.getRuntime().freeMemory())/1024;
    }
    
    //============================================================================================
    public class runDNA extends Thread
    {
         public void run()
         {
            for(int i=0;i<Integer.parseInt(runningLoopTXT.getText());i++)
            {
                runDNAforShortestPath(false);
                progress.setValue(i+1);
                 
                routeCount++;        
                totalcorrectRoutes+=correctRoutes;
                //Utilities.showMessage(totalcorrectRoutes+"    "+routeCount, "");
                averageCorrectRoutes=totalcorrectRoutes/routeCount;
            }
         }
    }
    //==========================================================================================
    private void setProgress()
    {
        progress.setValue(0);
        progress.setMaximum(0);
        progress.setMaximum(Integer.parseInt(runningLoopTXT.getText()));
        progress.setStringPainted(true);
    }    
    //==========================================================================================
    private String getRandomNumber()
    {
        if(!jobSchedulingRadio.isSelected())
            return (shortestPath.verticesStrands.size()*shortestPath.edgeStrands.size()/Integer.parseInt(didiveInitial.getText()))+"";
        
        return (shortestPath.verticesStrands.size()*shortestPath.edgeStrands.size()/Integer.parseInt(didiveInitial.getText())*randomSolutionFactor)+"";            
    }
    //==========================================================================================//===================================================================================
    private void runDNAforShortestPath(boolean evolutionary)
    {
        String reultFileName="FinalResults.txt";
        solutionsTXT.setText(getRandomNumber());
        jLabel3.setText("RNDS ("+shortestPath.verticesStrands.size()+"*"+shortestPath.edgeStrands.size()+")");
        runningMode=shortestPath.verticesStrands.size()+","+shortestPath.edgeStrands.size();
            if(repAddStEndCHK.isSelected()) runningMode+=",RepAddSE";
            if(eVolSSCP.isSelected() && evolutionary) runningMode+=",evolSCCP";
            runningMode+=",CrossOver"+eDNAtype;
            
        // running DNA Algorithm for Shortest Path Problem
        this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
        startTime = System.currentTimeMillis();

        try
        {
            if(jobSchedulingRadio.isSelected())
                reultFileName="js-"+reultFileName;
            else
                reultFileName="sp-"+reultFileName;
            
            if(evolutionary)
                  reultFileName="eDNA-"+reultFileName;
            else
                reultFileName="DNA-"+reultFileName;
            
            totalStream= new FileWriter(reultFileName,true);
            totalOut= new BufferedWriter(totalStream);
            
        }catch(Exception e){Utilities.showMessage(e.getMessage(), "Total File Exception");}

        getBeginMemory();

        if(evolutionary)
            prepareOperation("eRes-"+inputFileTXT.getText()+"--");
        else
            prepareOperation("Res-"+inputFileTXT.getText()+"--");
        
        randomSolutionOperation();
        pcrOperation(evolutionary); // not using genetic algorithm
        sscpOperation(evolutionary);
        gelOperation();
        getEndMemory();
       
        if(jobSchedulingRadio.isSelected())
        {
             calculateJobWaitsTurns();
            addToSummary("Shorest Waiting Time= "+sortedWaits.get(0));
            addToSummary("Shorest Turnng  Time= "+sortedTurns.get(0));
        }
        
        
        writeSummaries(evolutionary);
        
        if(showSummCHBX.isSelected())
        {
            if(jobSchedulingRadio.isSelected())
                showAllJobs();                 
            else
                showAllRoutes();                
        }
        
            //Network	Nodes	Edges	Iterations	Random Solutions	PCR Solutions	sscped Solutions  sscped Paths Weights
            //Initialize Time	Random Sol Time	PCR Time	sscped Time	Total DNA Time	Total Running Time	Memory Usage
           // runningMode=shortestPath.verticesStrands.size()+":"+shortestPath.edges.size()+":";
                     
            /*totalOut.write(runningMode
                    +":totalLigations:"+shortestPath.annealingIterations+
                    ":Randomsolutions:"+shortestPath.randomSolutions.size()+":PCRSolutions:"+shortestPath.pcrSolutions.size()+
                    ":SSCPSolutions:"+shortestPath.sscpSolutions.size()+":TotalRoutes:"+shortestPath.weightedRealSolutions.size()+
                    ":CorrectRoutes:"+correctRoutes+":WrongRoutes:"+wrongRoutes+":ShortestPath:"+shortestPath.weights.get(0)+   
                ":TotalTime:"+((endTime-startTime)/1000F)+
                ":MemoryUsage:"+(heapFreeSizeBeg-heapFreeSizeEnd)+
                ":DroppedPCR:"+shortestPath.initilaDropedPCR+":PCRcrossOvers:"+shortestPath.pcrMutations+":ePCRGenerated:"+shortestPath.ePCRgenerated+
                ":DroppedSSCP:"+shortestPath.initialDropedsscp+":SSCPcrossOvers:"+shortestPath.sscpMutations
                    +":eSSCPGenerated:"+shortestPath.eSscpGenerated+":TotalEvolSSCPcross:"+shortestPath.evolCrossOvers+":LeastWeight:"+shortestPath.leastWeight+"\n");*/
            
            
            
            // ":InitTime:"+shortestPath.initializePeriod+":RandomTime:"+shortestPath.randomSolPeriod+
            // ":PCRTime:"+shortestPath.pcrPeriod+":SSCPTime:"+shortestPath.sscpPeriod+
            //  ":OtherTime:"+(shortestPath.otherPeriod+
            // shortestPath.sscpPeriod+shortestPath.pcrPeriod+
            //shortestPath.randomSolPeriod+shortestPath.initializePeriod)+
            
        if(jobSchedulingRadio.isSelected())
            writeSummaryResultsToFileSchedule();
        else
            writeSummaryResultsToFile();
           
        if(saveReultsCHCK.isSelected())
            try{ out.close();}catch(Exception e){Utilities.showMessage(e.getMessage(), "Close File Exception");}

        //try{ totalOut.close();}catch(Exception e){Utilities.showMessage(e.getMessage(), "Exception");}
        this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
    }
    //======================================================================================================================
    private void writeSummaryResultsToFile()
    {
        try{
        totalOut.write(runningMode
                    +","+shortestPath.annealingIterations+","+shortestPath.randomSolutions.size()+","+shortestPath.pcrSolutions.size()+
                    ","+shortestPath.sscpSolutions.size()+","+shortestPath.gelWeights.size()+
                    ","+correctRoutes+","+wrongRoutes+","+shortestPath.weights.get(0)+","+((endTime-startTime)/1000F)+
                ","+(heapFreeSizeBeg-heapFreeSizeEnd)+","+shortestPath.initilaDropedPCR+","+shortestPath.pcrMutations+","+shortestPath.ePCRgenerated+
                ","+shortestPath.initialDropedsscp+","+shortestPath.sscpMutations
                    +","+shortestPath.eSscpGenerated+","+shortestPath.evolCrossOvers+","+shortestPath.leastWeight+"\n");
         totalOut.close();            
         clearObjects();
        }
        catch(Exception e)
        { 
            //Utilities.showMessage(e.getMessage(), "Exception");
            try{ totalOut.write(runningMode+"-No Solution Found\n"); }catch(Exception exp){}
        
        }
    }
    //======================================================================================================================
    private void writeSummaryResultsToFileSchedule()
    {
        try{
        totalOut.write(runningMode
                    +","+shortestPath.annealingIterations+","+shortestPath.randomSolutions.size()+","+shortestPath.pcrSolutions.size()+
                    ","+shortestPath.sscpSolutions.size()+","+shortestPath.gelWeights.size()+
                    ","+correctRoutes+","+wrongRoutes+","+sortedWaits.get(0)+","+sortedTurns.get(0)+","+((endTime-startTime)/1000F)+
                ","+(heapFreeSizeBeg-heapFreeSizeEnd)+","+shortestPath.initilaDropedPCR+","+shortestPath.pcrMutations+","+shortestPath.ePCRgenerated+
                ","+shortestPath.initialDropedsscp+","+shortestPath.sscpMutations
                    +","+shortestPath.eSscpGenerated+","+shortestPath.evolCrossOvers+","+shortestPath.leastWeight+"\n");
         totalOut.close();            
         clearObjects();
        }
        catch(Exception e)
        { 
            //Utilities.showMessage(e.getMessage(), "Exception");
            try{ totalOut.write(runningMode+"-No Solution Found\n"); }catch(Exception exp){}
        
        }
    }
    //===================================================================================
    private void clearObjects()
    {
        shortestPath.pcrSolutions.clear();
        shortestPath.sscpSolutions.clear();
        shortestPath.firstSscpSolutionsForEvolSSCP.clear();
        shortestPath.pcrSolutions.clear();
        shortestPath.droppedPcrSolutions.clear();
        shortestPath.dropedSscpSolutions.clear();
        shortestPath.fileLines.clear();
        shortestPath.gelSolutions.clear();
        shortestPath.mutationSeperatedNodes.clear();
        shortestPath.pcrRealSolutions.clear();
        shortestPath.pcrSolutions.clear();
        shortestPath.sscpRealSolutions.clear();
        shortestPath.sscpSolutions.clear();
        shortestPath.weightedSeperatedNodes.clear();
        shortestPath.weightedRealSolutions.clear();
        shortestPath.tempSscpSolutions.clear();
        shortestPath.tempPcrSolutions.clear();
        
    }
    //===================================================================================//===================================================================================    //============================================================================================
    public class runeDNA extends Thread
    {
         public void run()
         {
            for(int i=0;i<Integer.parseInt(runningLoopTXT.getText());i++) 
            {
               runDNAforShortestPath(true);
               progress.setValue(i+1);
               routeCount++;
               totalcorrectRoutes+=correctRoutes;
               averageCorrectRoutes=totalcorrectRoutes/routeCount;
            }
         }
    }
     //==================================================================================
     public static void sleep(int secs)
     {
          try
          {
                Thread.sleep(secs);
          } catch (InterruptedException e)
          {e.printStackTrace();}
     }
    //===================================================================================    //===================================================================================
    private String getFileStamp()
    {
        Calendar now = Calendar.getInstance();
        int year = now.get(Calendar.YEAR);
        int month = now.get(Calendar.MONTH); // Note: zero based!
        int day = now.get(Calendar.DAY_OF_MONTH);
        int hour = now.get(Calendar.HOUR_OF_DAY);
        int minute = now.get(Calendar.MINUTE);
        int second = now.get(Calendar.SECOND);
        int millis = now.get(Calendar.MILLISECOND);

        return  year+"-"+(month+1)+"-"+day+"---"+hour+"-"+minute+"-"+second+"-"+millis;
    }
    //===================================================================================
    private void writeToFile(String title, String text)
    {
        if(showBasicInfoCHKBX.isSelected())
             if(saveReultsCHCK.isSelected() && !outTotalCHBX.isSelected())
                     try{ out.write(title+": "+text+"\n");}catch(Exception e){ Utilities.showMessage(e.getMessage(), "Result Write To FileException");}
    }
    //===================================================================================
    private void writeToTotalFile(String title, String text)
    {
        try{ totalOut.write(title+": "+text);}catch(Exception e){ Utilities.showMessage(e.getMessage(), "Exception");}
    }
     //===================================================================================
    private void showItem(String itemName, ArrayList list)
    {
        if(showBasicInfoCHKBX.isSelected())
        {
        //addToSummary(itemName+"= "+list.size());
        shortestPathResult.setText("\n"+shortestPathResult.getText()+itemName+"("+list.size()+"):--------------------------------------------\n");
        writeToFile("\n"+itemName,":("+list.size()+"):--------------------------------------------\n");
        for(int i=0;i<list.size();i++)
        {
            shortestPathResult.setText(shortestPathResult.getText()+"("+(i+1)+")- "+list.get(i)+"\n");
            if(itemName.startsWith("Random Solution"))
            {
                shortestPathResult.setText(shortestPathResult.getText()+"("+(i+1)+")- "+list.get(i)+" : "+shortestPath.getRealName(list.get(i)+"")+"\n");
                writeToFile("("+(i+1)+") ",list.get(i)+" : "+shortestPath.getRealName(list.get(i)+"")+"\n");
            }
            else
            {
                shortestPathResult.setText(shortestPathResult.getText()+"("+(i+1)+")- "+list.get(i)+"\n");
                writeToFile("("+(i+1)+") ",list.get(i)+"\n");
            }
        }
        }
    }
     //===================================================================================
    private void showItemHash(String itemName, Hashtable hash, Hashtable weiths)
    {
        wrongRoutes=0;
        addToSummary(itemName+"= "+hash.size());
        if(showBasicInfoCHKBX.isSelected())
            shortestPathResult.setText("\n"+shortestPathResult.getText()+itemName+"("+hash.size()+"):--------------------------------------------\n");
        writeToFile(itemName,":("+hash.size()+"):--------------------------------------------\n");
        Enumeration e = hash.keys();
        int i=0; String nextElemenet="";
        while( e. hasMoreElements() )
        {
            try{
            nextElemenet=e.nextElement()+"";
            if(showBasicInfoCHKBX.isSelected())
            {
                shortestPathResult.setText(shortestPathResult.getText()+"("+(i+1)+")- ("+weiths.get(nextElemenet)+") "+nextElemenet+" : "+hash.get(nextElemenet)+"\n");
                 writeToFile("("+(i+1)+")- ","("+weiths.get(nextElemenet)+") "+nextElemenet+" : "+hash.get(nextElemenet)+"\n");
            }
            i++;

             if(itemName.equals("All Routes"))
                 if((hash.get(nextElemenet)+"").trim().equals("No Route"))
                        wrongRoutes++;

            }catch(Exception exp ) {Utilities.showMessage(exp.toString(),itemName+" -- "+exp.getMessage());}
        }
    }
    //===================================================================================
    private void showVerticesStrands(Hashtable strands,ArrayList list,Hashtable compStrands,Hashtable revCompStrands)
    {
        shortestPathResult.validate();
        addToSummary("Vertices= "+list.size());
        writeToFile("\nVertices ","("+list.size()+")---------------------------------------------------------------------\n");
        shortestPathResult.setText("Vertices ("+list.size()+"):----------------------------------------------------\n");
        initialDnaTXT.setText("Vertices ("+list.size()+"):----------------------------------------------------\n");
        initialDnaTXT.setText(shortestPathResult.getText()+"Start Node: "+shortestPath.startNode+ " ("+shortestPath.startNodeStrand+")  End Node: "+shortestPath.endNode+" ("+shortestPath.endNodeStrand+")\n");
        shortestPathResult.setText(shortestPathResult.getText()+"Start Node: "+shortestPath.startNode+ " ("+shortestPath.startNodeStrand+")  End Node: "+shortestPath.endNode+" ("+shortestPath.endNodeStrand+")\n");
        for(int i=0;i<list.size();i++)
        {
             shortestPathResult.setText(shortestPathResult.getText()+list.get(i)+" --> \t 5\'"+strands.get(list.get(i))+
                     "3\' \t  Comp: 3\'"+compStrands.get(list.get(i))+"5\' \t OR \t 5\'"+revCompStrands.get(list.get(i))+"3\'  \n");
             
              initialDnaTXT.setText(initialDnaTXT.getText()+list.get(i)+" --> \t 5\'"+strands.get(list.get(i))+
                     "3\' \t  Comp: 3\'"+compStrands.get(list.get(i))+"5\' \t OR \t 5\'"+revCompStrands.get(list.get(i))+"3\'  \n");

              writeToFile(list.get(i)+" --> \t 5\'",strands.get(list.get(i))+
                     "3\' \t  Comp: 3\'"+compStrands.get(list.get(i))+"5\' \t OR \t 5\'"+revCompStrands.get(list.get(i))+"3\'");
        }
        
    }//
    //===================================================================================
    private void addToSummary(String text)
    {
        summaryResultTXT.setText(summaryResultTXT.getText()+text+"\n");
    }
    //===================================================================================
    private void showEdgesStrands(Hashtable strands,ArrayList list,Hashtable weights)
    {
        shortestPathResult.setText("\n"+shortestPathResult.getText()+"Edges("+list.size()+"):----------------------------------------------------\n");
        addToSummary("Edges= "+list.size());
        writeToFile("\nEdges ","("+list.size()+")------------------------------------------------------------------------------------\n");
        for(int i=0;i<list.size();i++)
        {
             shortestPathResult.setText(shortestPathResult.getText()+list.get(i)+" --> 5'"+strands.get(list.get(i))+"3'\n");
              writeToFile(list.get(i)+" --> ","5\'"+strands.get(list.get(i))+"3' : "+weights.get(list.get(i))+"\n");
        }
    }
    //===================================================================================
    private void generateMap()
    {
        Clustering cluster=new Clustering();
        cluster.start();
        colorRightPanel.add(cluster);
        colorRightPanel.revalidate();
        colorRightPanel.repaint();


    }
    //===============================================================================
    private void clearNetwork(){
    this.setCursor(Cursor.getPredefinedCursor(Cursor.WAIT_CURSOR));
    pathRightPanel.removeAll();
    pathRightPanel.repaint();
    this.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
}
 //===================================================================================
    private void generateNetwork(){
    // Make a graph by a SparseMultigraph instance.
        Graph<Integer, String> g = new SparseMultigraph<Integer, String>();
        for(int i=0;i<verticesNo;i++)
            g.addVertex((Integer)(i+1)); // Add a vertex with an integer 1
        int vertix=1;
        for (int k=1;k<verticesNo+1;k++)
         for(int j=1;j<verticesNo+1;j++)
            g.addEdge("Edge"+(vertix++), k,j); // Added an edge to connect between 1 and 3 vertices.
        /*g.addEdge("Edge-B", 2,3, EdgeType.DIRECTED);
        g.addEdge("Edge-C", 3,2, EdgeType.DIRECTED);
        g.addEdge("Edge-P", 2,3); // A parallel edge*/

        // Make some objects for graph layout and visualization.
        Layout<Integer, String> layout = new KKLayout<Integer, String>(g);
        BasicVisualizationServer<Integer, String> vv =
        new BasicVisualizationServer<Integer, String>(layout);
        vv.setPreferredSize(new Dimension(800,800));

        // It determine how each vertex with its value is represented in a diagram.
        ToStringLabeller<Integer> vertexPaint = new ToStringLabeller<Integer>() {
          public String transform(Integer i) {
          return ""+i;
         }
        };

        vv.getRenderContext().setVertexLabelTransformer(vertexPaint);
        pathRightPanel.add(vv);
        pathRightPanel.revalidate();
        pathRightPanel.repaint();
}
//===================================================================================
    /**
    * @param args the command line arguments
    */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new mainFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextPane SCHResultTXT;
    private javax.swing.JRadioButton ShortestPathRadio;
    private javax.swing.JMenuItem aboutBT;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.ButtonGroup buttonGroup3;
    private javax.swing.ButtonGroup buttonGroup4;
    private javax.swing.ButtonGroup buttonGroup5;
    private javax.swing.ButtonGroup buttonGroup6;
    private javax.swing.JButton clearNetBT;
    private javax.swing.JPanel colorLeftPanel;
    private javax.swing.JPanel colorPanel;
    private javax.swing.JPanel colorRightPanel;
    private javax.swing.JTabbedPane colorTab;
    private javax.swing.JMenuItem copyBT;
    private javax.swing.JMenuItem cutBT;
    private javax.swing.JTextField didiveInitial;
    private javax.swing.JRadioButton eBoth;
    private javax.swing.JRadioButton eNone;
    private javax.swing.JRadioButton ePCR;
    private javax.swing.JRadioButton eSSCP;
    private javax.swing.JCheckBox eVolSSCP;
    private javax.swing.JTextField edgesTXT;
    private javax.swing.JMenu editMenu;
    private javax.swing.JMenuItem exitBT;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenuItem forColorMapBT;
    private javax.swing.JButton genMapBT;
    private javax.swing.JButton generateNetBT;
    private javax.swing.JMenu helpMenu;
    private javax.swing.JTextPane initialDnaSCHTXT;
    private javax.swing.JTextPane initialDnaTXT;
    private javax.swing.JTextField inputFileTXT;
    private javax.swing.JTextField inputSCHFileTXT;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JRadioButton jobSchedulingRadio;
    private javax.swing.JMenuBar mainMenuBar;
    private javax.swing.JTabbedPane mainTab;
    private javax.swing.JTextField mutationsNoTXT;
    private javax.swing.JTextField mutationsSCHNoTXT;
    private javax.swing.JMenuItem openBT;
    private javax.swing.JButton openResultBT;
    private javax.swing.JCheckBox outTotalCHBX;
    private javax.swing.JMenuItem pasteBT;
    private javax.swing.ButtonGroup pathButtonGroup;
    private javax.swing.JPanel pathLeftPanel;
    private javax.swing.JPanel pathPanel;
    public javax.swing.JPanel pathRightPanel;
    private javax.swing.JTabbedPane pathTab;
    private javax.swing.JProgressBar progress;
    private javax.swing.JCheckBox repAddStEndCHK;
    private javax.swing.JButton resetCountersBT;
    private javax.swing.JButton runAllBT;
    private javax.swing.JCheckBox runAllCHBX;
    private javax.swing.JButton runDNASCHBT;
    private javax.swing.JButton runDNAshortestPathBT;
    private javax.swing.JButton runeDNASCHBT;
    private javax.swing.JButton runeDNAshortestPathBT;
    private javax.swing.JTextField runningLoopSchedTXT;
    private javax.swing.JTextField runningLoopTXT;
    private javax.swing.JCheckBox saveReultsCHCK;
    private javax.swing.JCheckBox saveSCHReultsCHCK;
    private javax.swing.JButton schCodingBT;
    private javax.swing.JPanel scheduleLeftPanel;
    private javax.swing.JPanel schedulePanel;
    private javax.swing.JPanel scheduleRightPanel;
    private javax.swing.JTabbedPane scheduleTap;
    private javax.swing.JTextPane shortestPathResult;
    private javax.swing.JCheckBox showBasicInfoCHKBX;
    private javax.swing.JCheckBox showBasicSchedCHKBX;
    private javax.swing.JCheckBox showPCRCHBX;
    private javax.swing.JCheckBox showResultsCHKBX;
    private javax.swing.JCheckBox showSummCHBX;
    private javax.swing.JCheckBox showSynthCHBX;
    private javax.swing.JMenuItem shrtestPathBT;
    private javax.swing.JTextPane solutionsSCHTXT;
    private javax.swing.JTextPane solutionsTXT;
    private javax.swing.JTextPane summaryResultTXT;
    private javax.swing.JTextPane summarySCHResultTXT;
    private javax.swing.JRadioButton template1;
    private javax.swing.JRadioButton template2;
    private javax.swing.JRadioButton template3;
    private javax.swing.JMenu toolsMenu;
    private javax.swing.JMenuItem utilitiesBT;
    private javax.swing.JTextField verticesTXT;
    // End of variables declaration//GEN-END:variables

}

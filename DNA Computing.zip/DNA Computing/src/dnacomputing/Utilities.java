/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// Created by Godar J. Ibrahim, Year 2011
// godar.ibrahim@su.edu.krd
// godar@awrosoft.com

package dnacomputing;
import javax.swing.*;

import java.util.Calendar;
import java.text.SimpleDateFormat;
/**
 *
 * @author godar
 */
public class Utilities {


     public static final String DATE_FORMAT_NOW = "yyyy-MM-dd--HH-mm-ss";

    public static void showMessage(String msg,String title)
    {
         JOptionPane.showMessageDialog(null, msg,title, JOptionPane.ERROR_MESSAGE);
    }

    public static String getDateTime()
    {
        Calendar cal = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
        return sdf.format(cal.getTime());
    }

}

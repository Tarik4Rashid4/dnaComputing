/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// Created by Godar J. Ibrahim, Year 2011
// godar.ibrahim@su.edu.krd
// godar@awrosoft.com

package dnacomputing;

import java.io.*;
import java.util.*;
/**
 *
 * @author Godar
 */
public class schDNA
{
    private static Random m_rand = new Random();  // random-number generator
    public ArrayList<String> fileLines= new ArrayList<String>();

    private String inputFile="SCH-2-5-6.txt";
    public long startTime,endTime; // for calculating elapsed time
    public float initializePeriod,randomSolPeriod, pcrPeriod, gelPeriod, sscpPeriod, geneticPeriod,otherPeriod;

     //==================================================================================
    public void initializae(String inFile)
    //Steps: 1-Watson-Crick Pairing, 2-Polymerase, 3-Ligase, 4-Restriction Enzymes
    {

        startTime = System.currentTimeMillis();
        inputFile=inFile+".txt";

        fileLines=getFileContens(); // get the contents of the input file, line by line       

        endTime = System.currentTimeMillis();
        initializePeriod=(endTime-startTime)/1000F;
    }
     //==================================================================================
    private ArrayList getFileContens() // getting lines including nodes, routes, weights
    {
        ArrayList<String> list= new ArrayList<String>();

        try{

                FileInputStream fstream = new FileInputStream("T:/Postgraduate Studying/My Thesis/Practical Project/DNAcomputing/src/dnacomputing/"+inputFile);
                DataInputStream in = new DataInputStream(fstream);
                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                String strLine;

                while ((strLine = br.readLine()) != null)
                {
                        list.add(strLine);
                        Utilities.showMessage(strLine, strLine);

                }
                in.close();
             }
            catch (Exception e)
            {
                  Utilities.showMessage("Error: " + e.getMessage(),"");
            }
        return list;
    }
     //==================================================================================
}



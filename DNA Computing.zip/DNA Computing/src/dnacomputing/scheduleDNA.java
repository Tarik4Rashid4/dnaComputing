/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// Created by Godar J. Ibrahim, Year 2011
// godar.ibrahim@su.edu.krd
// godar@awrosoft.com

package dnacomputing;

import java.io.*;
import java.util.*;

/**
 *
 * @author godar
 */
public class scheduleDNA 
{

    //==================================================================================//
    public ArrayList<String> fileLines= new ArrayList<String>();
    private String inputFile="shortestPath.txt";
    public long startTime,endTime; // for calculating elapsed time
    public float initializePeriod,randomSolPeriod, pcrPeriod, gelPeriod, sscpPeriod,otherPeriod;
       
    public ArrayList<String> distinctVertices= new ArrayList<String>();
    public Hashtable verticesStrands = new Hashtable();      // vertise name, vertise strand
    public Hashtable verticesVersaStrands = new Hashtable(); // vertise strand, vertise name
    public Hashtable compVerticesStrands = new Hashtable();  // vertise name, vertise comp strand
    public Hashtable revesredCompVerticesStrands = new Hashtable(); // vertise name, vertise reversed comp strand

    public String startNode="", endNode="";             // start & end node names
    public String startNodeStrand="", endNodeStrand="";  // start & end node strands
    
    public ArrayList<String> edgeStrands= new ArrayList<String>(); // strands of all edges
    public ArrayList<String> nodeStrands= new ArrayList<String>(); // strands of all vertices
    
    int palindromeDNA=10;  // length of the palidrome strand
    
    public ArrayList<String> edges= new ArrayList<String>(); // all Edges: A-B
    public Hashtable edgeStrandsHash = new Hashtable();     // Edge Strands: A-B, ATGCTGACTG
    public Hashtable edgeWeights = new Hashtable();         // Edge Wrights: A-B, 3
    public Hashtable sythWeights = new Hashtable();
    public Hashtable gelWeights = new Hashtable();
    public Hashtable weightedRealSolutions = new Hashtable();

    public List<String> weights = new ArrayList<String>();
    
    public ArrayList<String> testTube= new ArrayList<String>();   // Containing Node & Edge Strands
    public ArrayList<String> randomSolutions= new ArrayList<String>(); // Saving Random Solution Strands
    //==================================================================================
    public void initializae(String inFile)
    //Steps: 1-Watson-Crick Pairing, 2-Polymerase, 3-Ligase, 4-Restriction Enzymes
    {         
        startTime = System.currentTimeMillis();
        inputFile=inFile;
        
        
        fileLines=getFileContens(); // get the contents of the input file, line by line
        distinctVertices=getDistinctVerticesEdges(fileLines); // returns distinct Nodes and save Edge & Edge Weights
        verticesStrands=generateRandomStrands(distinctVertices); // returns generated random Strand for Nodes and save them in Test Tube
        edgeStrandsHash=getEdgeStrandsHash(edges, verticesStrands);  // returns strands of edges and save them in Test Tube

        endTime = System.currentTimeMillis();
        initializePeriod=(endTime-startTime)/1000F;
    }
     //==================================================================================
    //==================================================================================
     private String generateRandomStrand(int length)
     {
          String charset = "ATGC";

          Random rand = new Random(System.currentTimeMillis());
          StringBuilder sb = new StringBuilder();
          for (int i = 0; i < length; i++)
          {
                int pos = rand.nextInt(charset.length());
                sb.append(charset.charAt(pos));
          }
          sleep(10);
          return sb.toString();
     }
     //==================================================================================
     public static void sleep(int secs)
     {
          try
          {
                Thread.sleep(secs);
          } catch (InterruptedException e)
          {e.printStackTrace();}
     }
     //==================================================================================
    private Hashtable getEdgeStrandsHash(ArrayList allEdges, Hashtable vericeStrands)
            // returns strands of edges and save them in Test Tube
    {
        Hashtable edgeStrand=new Hashtable();
        String[] temp;
        String ligasedStrand="";

        edgeStrands.clear();
        for(int i=0;i<allEdges.size();i++)
        {
            temp=(allEdges.get(i)+"").split("-");
            ligasedStrand=makeEdge(vericeStrands.get(temp[0])+"",vericeStrands.get(temp[1])+"");
            edgeStrand.put(allEdges.get(i)+"",ligasedStrand);

            edgeStrands.add(ligasedStrand);
            testTube.add(ligasedStrand); // Put Edge Strand in Test Tube
            //testTube.add(ligasedStrand); // Put Edge Strand in Test Tube again; duplication
            //testTube.add(ligasedStrand); // Put Edge Strand in Test Tube again; duplication
        }
       // duplicateTestTube();
        return edgeStrand;
    }
     //==================================================================================
    private String getReverseStrand(String origStrand)
    {
        String reversed="";

        for (int i=0; i<origStrand.length(); i++)
           reversed = origStrand.substring(i, i+1) + reversed;

           return reversed.toUpperCase();
    }
    //==================================================================================
    private String makeEdge(String firstStrand, String secondStrand)
    {
        String ligised="",second="";
        int halfIndex=firstStrand.length()/2;

        for(int i=0;i<halfIndex;i++)
            ligised+=firstStrand.substring((halfIndex+i),(halfIndex+i)+1);
        ligised=getComplementStrand(ligised);
        for(int j=0;j<halfIndex;j++)
             second+=secondStrand.substring(j,j+1);
        second=getComplementStrand(second);

        return ligised+second;
    }
    //==================================================================================
    private boolean isWrongStrand(String strand)
    {
        String str=strand.toUpperCase();
        for(int i=0;i<str.length();i++)
            if(!str.substring(i, i+1).equals("A") && !str.substring(i, i+1).equals("T")
            && !str.substring(i, i+1).equals("G") && !str.substring(i, i+1).equals("C"))
                return true;

        return false;
    }
    //==================================================================================
    private String getComplementBase(String origBase)
    {
       String comp=origBase;
       if(origBase.equals("A") || origBase.equals("a"))
          comp="T";
        else if(origBase.equals("T") || origBase.equals("t"))
          comp="A";
       else if(origBase.equals("G") || origBase.equals("g"))
          comp="C";
       else if(origBase.equals("C") || origBase.equals("c"))
          comp="G";

       return comp;

    }
    //==================================================================================
    private String getComplementStrand(String origStrand)
    {
        String compStrand="";
        for(int i=0;i<origStrand.length();i++)
            compStrand+=getComplementBase(origStrand.substring(i, i+1));

        return compStrand;
    }
    //=================================================================================
    private Hashtable generateRandomStrands(ArrayList list)
            // returns generated random Strand for Nodes and save them in Test Tube
    {   
        Hashtable strandsDic=new Hashtable();
        compVerticesStrands.clear();
        revesredCompVerticesStrands.clear();
        testTube.clear();
        nodeStrands.clear();

        String tempStrand="";
        for(int i=0;i<list.size();i++)
        {
            tempStrand=generateRandomStrand(palindromeDNA);
            nodeStrands.add(tempStrand);
            strandsDic.put(list.get(i)+"",tempStrand);
            verticesVersaStrands.put(tempStrand, list.get(i)+"");
            compVerticesStrands.put(list.get(i)+"", getComplementStrand(tempStrand));
            revesredCompVerticesStrands.put(list.get(i)+"",getReverseStrand(getComplementStrand(tempStrand)));

            testTube.add(tempStrand); // put node Strand into Test Tube
        }
        startNodeStrand=strandsDic.get(startNode)+"";
        endNodeStrand=strandsDic.get(endNode)+"";

        return strandsDic;
    }
    //************************************ Initialize Start *************************************************************
    //==================================================================================
     private ArrayList getFileContens() // getting lines including nodes, routes, weights
    {
        ArrayList<String> list= new ArrayList<String>();

        try{

                FileInputStream fstream = new FileInputStream("D:/Postgraduate Studying/My Thesis/Practical Project/DNAcomputing/src/dnacomputing/"+inputFile);
                DataInputStream in = new DataInputStream(fstream);
                BufferedReader br = new BufferedReader(new InputStreamReader(in));
                String strLine;

                while ((strLine = br.readLine()) != null)
                        list.add(strLine);
                in.close();
             }
            catch (Exception e)
            {
                  Utilities.showMessage("Error: " + e.getMessage(),"");
            }
        return list;
    }
     //==================================================================================
    private ArrayList getDistinctVerticesEdges(ArrayList list)
            // return distinct Nodes and save Edges, Edge Weights
    {
        ArrayList<String> distNodes= new ArrayList<String>();
        String[] temp;
        edges.clear();
        for(int i=0;i<list.size();i++)
        {
            temp = (list.get(i)+"").split(",");
            if(i==0)
            {
                startNode=temp[0];
                endNode=temp[1];
            }
            else
            {
                distNodes.add(temp[0]);
                distNodes.add(temp[1]);

                edges.add(temp[0]+"-"+temp[1]); // save all edges here
                edgeWeights.put(temp[0]+"-"+temp[1],temp[2]);
            }
        }

        HashSet hs = new HashSet();
        hs.addAll(distNodes); //to sort them
        distNodes.clear();
        distNodes.addAll(hs);

        Collections.sort(distNodes); // sorting the vertices
        return distNodes;

    }
    //=================================================================================
    //==================================================================================
    public String getRealName(String strandString)
    {
        String realNameString="";
        ArrayList<String> sepNodes= new ArrayList<String>();
        sepNodes=getChunkStrings(strandString+"",palindromeDNA);
        for(int j=0;j<sepNodes.size();j++)
           realNameString+=verticesVersaStrands.get(sepNodes.get(j))+"->";

        return realNameString;
    }
    
    //==================================================================================
    private ArrayList getChunkStrings(String strand, int nchars)
    {
        ArrayList<String> temp= new ArrayList<String>();
        int len = strand.length();

        for (int i=0; i<len; i+=nchars)
        {
            temp.add(strand.substring(i, Math.min(len, i + nchars)));
        }

        return temp;
    }
    //==================================================================================//
    
    //==================================================================================//
    
    //==================================================================================//
    
    //==================================================================================//
    
}

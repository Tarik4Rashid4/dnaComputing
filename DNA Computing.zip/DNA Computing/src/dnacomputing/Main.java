/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

// Created by Godar J. Ibrahim, Year 2011
// godar.ibrahim@su.edu.krd
// godar@awrosoft.com

package dnacomputing;

import javax.swing.*;
/**
 *
 * @author godar
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
       mainFrame mainFRM=new mainFrame();
       mainFRM.setLocationRelativeTo(null); // centering
       // maximize the jframe here
       mainFRM.setExtendedState(mainFRM.getExtendedState()|JFrame.MAXIMIZED_BOTH);
       mainFRM.show();
        // TODO code application logic here
    }

}
